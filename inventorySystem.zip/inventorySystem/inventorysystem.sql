-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 10, 2013 at 03:46 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventorysystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE IF NOT EXISTS `division` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `division` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`id`, `division`) VALUES
(29, 'ADMINISTRATIVE AND FINANCE '),
(30, 'PMED'),
(31, 'finance');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `mi` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `division` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `firstname`, `lastname`, `mi`, `address`, `division`) VALUES
(14, 'jameel', 'basher', 'a', 'maura', 'PMED'),
(15, 'angel', 'encarnacon', 'f', 'aaaa', 'ADMINISTRATIVE AND FINANC'),
(18, 'gfdg', 'gfd', 'gfd', 'gfdg', 'ADMINISTRATIVE AND FINANC'),
(20, 'hgfh', 'gfh', 'hgf', 'ew', 'PMED'),
(21, 'xds', 'fsdf', 'fsdf', 'fsdf', 'PMED'),
(23, 'dasd', 'dasd', 'dasds', 'dsd', 'ADMINISTRATIVE AND FINANC'),
(24, 'fds', 'fsd', 'fsdf', 'fsdf', 'ADMINISTRATIVE AND FINANC');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `session_id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `session_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`session_id`, `username`, `session_date`) VALUES
(4, 'jameel', '2013-03-10 03:36:34'),
(7, 'jaleel', '2013-03-10 03:43:57'),
(8, 'boniejane', '2013-01-14 04:40:43'),
(9, 'jasmin', '2013-01-14 04:48:03'),
(10, 'carmen', '2013-01-16 04:55:11'),
(12, 'jerick', '2013-01-21 01:07:52');

-- --------------------------------------------------------

--
-- Table structure for table `tblrequest`
--

CREATE TABLE IF NOT EXISTS `tblrequest` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `division` varchar(50) NOT NULL,
  `description` varchar(40) NOT NULL,
  `unitcost` varchar(15) NOT NULL,
  `unit` varchar(15) NOT NULL,
  `qty` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=200 ;

--
-- Dumping data for table `tblrequest`
--

INSERT INTO `tblrequest` (`id`, `name`, `date`, `division`, `description`, `unitcost`, `unit`, `qty`) VALUES
(197, 'aaa', '12/2/2012', 'ADMINISTRATIVE AND FINANCE ', 'bond', 'P108', 'ream', 3),
(198, 'aaa', '12/2/2012', 'ADMINISTRATIVE AND FINANCE ', 'aaa', 'P4.5', 'aaa', 3),
(199, 'aa', '', 'ADMINISTRATIVE AND FINANCE ', 'bbbb', 'P5', 'ffff', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblsupply`
--

CREATE TABLE IF NOT EXISTS `tblsupply` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `img` varchar(35) NOT NULL,
  `description` varchar(30) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `unitcost` float NOT NULL,
  `date` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=79 ;

--
-- Dumping data for table `tblsupply`
--

INSERT INTO `tblsupply` (`id`, `img`, `description`, `unit`, `quantity`, `unitcost`, `date`) VALUES
(66, 'add.png', 'aaaa', 'sa', 3, 3, '02/05/2013'),
(67, 'amuni.jpg', 'bbbb', 'ffff', 3, 5, '02/05/2013'),
(68, 'edit.gif', 'ccccc', 'ccc', 50, 5, '02/05/2013'),
(69, 'add.png', 'dasdas', 'dasd', 3, 3, '11/22/13'),
(70, 'add.png', 'gfgf', 'fgf', 0, 6, '11/22/13'),
(71, 'add.png', 'dasdas', 'dasd', 3, 3, '11/22/13'),
(72, 'add.png', 'gfgf', 'fgf', 0, 6, '11/22/13'),
(73, 'add.png', 'dasdas', 'dasd', 3, 3, '11/22/13'),
(74, 'add.png', 'gfgf', 'fgf', 0, 6, '11/22/13'),
(75, 'add.png', 'dasdas', 'dasd', 3, 3, '11/22/13'),
(76, 'add.png', 'gfgf', 'fgf', 0, 6, '11/22/13'),
(77, 'add.png', 'dasdas', 'dasd', 3, 3, '11/22/13'),
(78, 'add.png', 'gfgf', 'fgf', 0, 6, '11/22/13');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE IF NOT EXISTS `tbluser` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `firstname`, `lastname`, `username`, `password`, `type`, `confirmation`) VALUES
(41, 'Jameel', 'Bashers', 'Jameel', 'jameel', 'admin', '1'),
(42, 'jaleel', 'basher', 'jaleel', 'jaleel', 'PMED', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
