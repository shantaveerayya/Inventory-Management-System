<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />

<div class="headerContainer">
      <div class="headerLeft">
        <img src="../Images/header.png" />
      </div>
      <div class="headerRight">
        <!--<div class="searchContainer">
         <img src="../Images/search.png" class="search" />
         <input type="text" size="29" class="search" placeholder="GOOGLE SEARCH..."/>
        </div>-->
      </div>
 </div>