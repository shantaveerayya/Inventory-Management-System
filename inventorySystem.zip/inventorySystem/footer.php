<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
 <div class="footerContainer">
     <div class="footerMain">
       <div class="footerLeft">
        <p class="footer">
         Jameel A. Basher<br />
         Master of Science in Information Technology<br /><br />
         Online Inventory System<br />
         All Rights Reserved. &copy; Copyright 2012.<br /><br />
        </p>
       </div>
       
       <div class="footerRight">
        <p class="footer1">Best viewed in Mozilla Firefox 15.0 or Higher</p>
       </div>
     </div>
   </div>