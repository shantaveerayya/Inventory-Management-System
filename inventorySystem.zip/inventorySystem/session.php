<?php
// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['is']['username'])) 
  {
        echo '<meta http-equiv="refresh" content="2;url=index.php">';
  }
  
if (empty($_SESSION['is']['username']))
  {
	    echo '<meta http-equiv="refresh" content="2;url=index.php">';
  }
?>