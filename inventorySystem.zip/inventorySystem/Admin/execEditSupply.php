<?php
include ("../connection.php");

$id = $_REQUEST['id'];
$desc = $_REQUEST['description'];
$unit = $_REQUEST['unit'];
$date = $_REQUEST['date1'];
$qty = $_REQUEST['qty'];
$uc = $_REQUEST['unitcost'];

$insert = mysql_query("UPDATE tblsupply SET id = '$id', description = '$desc', unit = '$unit', quantity = '$qty', unitcost = '$uc', date = '$date'");

if(!$insert){

die("There's little problem: ".mysql_error());

}

echo '<meta http-equiv="refresh" content="1;url=supply.php">';
//echo "<a href='adddivisions.php'>back</a>";
?>


