<?php
include ("../connection.php");

$qty = $_REQUEST['sum4'];
$unitcost = $_REQUEST['sum5'];
$date = $_REQUEST['date1'];
$id = $_REQUEST['id'];

$insert = mysql_query("UPDATE tblsupply SET quantity = '$qty', unitcost = '$unitcost', date = '$date' WHERE id ='$id'");

if(!$insert){

die("There's little problem: ".mysql_error());

}

echo '<meta http-equiv="refresh" content="1;url=supply.php">';
//echo "<a href='adddivisions.php'>back</a>";
?>


