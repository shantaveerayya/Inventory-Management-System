 <link rel="stylesheet" href="../Date/jquery-ui.css"/>
 <script src="../Date/jquery1.js"></script>
 <script src="../Date/jquery2.js"></script>

 <script>
    $(function() {
        $( "#datepicker" ).datepicker();
    });
 </script>
	
<script type="text/javascript">
function validateForm()
{
var a=document.forms["addSup"]["description"].value;
if (a==null || a=="")
  {
  alert("Description is empty!");
  return false;
  }
var b=document.forms["addSup"]["unit"].value;
if (b==null || b=="")
  {
  alert("Unit is emplty!");
  return false;
  }
 var c=document.forms["addSup"]["date"].value;
if (c==null || c=="")
  {
  alert("Date is empty!");
  return false;
  }
var d=document.forms["addSup"]["qty"].value;
if (d==null || d=="")
  {
  alert("Quantity is empty!");
  return false;
  }
 var e=document.forms["addSup"]["unitcost"].value;
if (e==null || e=="")
  {
  alert("Unit Cost is empty!");
  return false;
  }
}
</script>
<SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>
   
		
<link rel="stylesheet" type="text/css" href="../CSS/general.css"/>
<link rel="stylesheet" type="text/css" href="../CSS/modalWindow.css"/>

<div class="modCon">
 <center>
   <div class="modHeader">
    <h3 class="modalHeader">
    ADD SUPPLY
    </h3>
   </div>
 <form action="execEditSupply.php" method="post" enctype="multipart/form-data" name="addSup" onsubmit="return validateForm()">  
   <div class="modContent">
    <div class="Row1">
	  
	  <table border="0" width="482">
	   <tr>
	     <td width="350">
		  Description
		 </td>
		 <td width="">
		  Unit
		 </td>
	   </tr>
	   
	   <tr>
	     <td width="310">
		 <?php
			include('../connection.php');
			$id =$_REQUEST['id'];
					
			$result=mysql_query("SELECT * FROM tblsupply WHERE id = '$id'");
			while($test = mysql_fetch_array($result))
			 {
			 $id = $test['quantity'];	
             $uc = $test['unitcost'];
			 $desc = $test['description'];
			 $unit = $test['unit'];
			 $date = $test['date'];	
			 $idd = $test['id'];	
			 }
		 ?>	
		 <input class="modText" type="hidden" tabindex="1" name="id" value="<?php echo $idd ?>" size="33" />
		  <input class="modText" type="text" tabindex="1" name="description" value="<?php echo $desc ?>" size="33" />
		 </td>
		 <td>
		  <input class="modText" type="text" tabindex="1" name="unit" value="<?php echo $unit ?>" size="11" />
		 </td>
	   </tr>
	   
	   <tr>
	     <td width="310">
		 
		 </td>
		 <td width="">
		  
		 </td>
	   </tr>
	   
	   <tr>
	     <table border="0" width="482">
		  <tr>
		   <td>
		    Date Purchased
		   </td>
		   <td>
		    
		   </td>
		   <td>
		   
		   </td>
		  </tr>
		  
		  <tr>
		   <td>
		    <input type="text" id="datepicker" class="modText" size="15" name="date1" readonly="readonly" value="<?php echo $date ?>"/>
		   </td>
		   <td>
		    <input class="modText" type="hidden" tabindex="1" name="qty" value="<?php echo $id ?>" size="9" onkeypress="return isNumberKey(event)" />
		   </td>
		   <td>
		    <input class="modText" type="hidden" tabindex="1" name="unitcost" value="<?php echo $uc ?>" size="10" onkeypress="return isNumberKey(event)"/>
		   </td>
		  </tr>
		 </table>
		 <tr> 
	   </tr>
	   
	   <tr>
	    <td height="75">
		 <input type="submit" name="submit" value="save" class="button" style="margin-top:10px; margin-left:4px;"/>
		</td>
	   </tr>	  
	  </table>
	   	
   </div>
  </form>
 </center>
</div>