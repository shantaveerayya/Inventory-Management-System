<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User's Log</title>
<script src="../filter/app.js" type="text/javascript" charset="utf-8"></script>
<script src="../filter/application.js" type="text/javascript" charset="utf-8"></script>
<!--box -->
<script language="javascript" src="../lib/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="../facebox/facebox.css" />

<script language="javascript" src="../facebox/facebox.js"></script>

<script language="javascript">
jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'facebox/loading.gif',
    
      })
    })
</script>
<!--endbox -->
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
<link rel="stylesheet" type="text/css" href="../CSS/modalWindow.css" />

<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script>
function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>
</head>

<body onload="startTime()">
 <center>
  <?php include("../menu.php"); ?>
 </center>
 
  <center>
   <?php include("../header.php"); ?>
  </center>
  
   <center>
     <div class="employee">
	   <div class="employeeHead">
	   
	    <div class="empTopLeft">
		 <div class="searchContainer1">
         <img src="../Images/google_custom_search.png" class="search1" />
         <input type="text" size="45" class="search1" placeholder="SEARCH..." name="filter" value="" id="filter"/>
		 <p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#00CC33;"></p>
         </div>
		</div>
		
		<div class="empTopRight"> 
		</div>		
	   </div>
	   
	   <div class="empCon">
	   
       <div class="viewuser">
      <table>
			<?php
			include('../connection.php');
			//include("session.php");
			
			$result=mysql_query("SELECT * FROM session ORDER BY session_date DESC");
			
			$color = "1";
			echo"<form method='post' name='form' id='form' action='delmultipleLog.php' onsubmit='return confirmdelete();'>";
			echo"
			   <thead>
			   <tr class='empHead'>
			       <td width='50' align='center'><input  id='delete' type='submit' name='delete' value='x'/></th>
			       <td width='110'>User</th>
   			       <td width='110'>Dte</th>
				   <td width='70'><center>Delete</center></th>
			    </tr>
				 </thead>";
			
			while($test = mysql_fetch_array($result))
			{
				if($color==1)
				 
				 {
				
					$id = $test['session_id'];	
					echo "<tbody>";
					echo "<tr class='View1emp'>";	
					echo"<td  align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo"<td>" .$test['username']."</td>";
					echo"<td>". $test['session_date']. "</td>";
					echo"<td width='70'><a href ='delusersLog.php?session_id=$id'><center><img class='editdelete'  src='../Images/group_delete.png' onclick='return confirmdelete();'/></center></a></td>";					
					echo "</tr>";
					echo "</tbody>";
					
					$color = "2";
				 }
				 
				 else
				 
				 {
					 $id = $test['session_id'];	
					 echo "</tbody>";
					echo "<tr class='View1emp'>";	
					echo"<td  align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo"<td>" .$test['username']."</td>";
					echo"<td>". $test['session_date']. "</td>";
					echo"<td width='70'><a href ='delusersLog.php?session_id=$id'><center><img class='editdelete'  src='../Images/group_delete.png' onclick='return confirmdelete();'/></center></a></td>";					
					echo "</tr>";
					echo "</tbody>";
					
					$color = "1";
				 }
				 
			}
			
			echo"</form>";
			mysql_close($conn);
			?>
</table>
   </div>
	   </div>
	 </div>
   </center> 
   
  
  <center>
   <?php include("../footer.php"); ?>  
  </center>
</body>
</html>