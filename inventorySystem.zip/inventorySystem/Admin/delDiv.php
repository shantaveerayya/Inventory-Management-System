<?php
  include("../connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	$del = mysql_query("DELETE FROM division WHERE id = '$id'")
	or die(mysql_error()); 

	header("Location: addDiv.php");
?>