<?php
	
	require '../connection.php';
			
	if($_POST['delete']) 
	{
		$checkbox = $_POST['checkbox']; 
		$countCheck = count($_POST['checkbox']);
		
		for($i=0;$i<$countCheck;$i++)
		{
			$del_id  = $checkbox[$i];
			
								
			$sql = "DELETE from division where id = $del_id";
			$result = mysql_query($sql) or die(mysql_error());
			
		}
			if($result)
		{	
				header('Location: addDiv.php');
			}
			else
			{
				echo "Please select atleast 1 record to delete ";
			}
	}
?>