

<style type="text/css">
#dvLoading

{
   background:#FFFFFF url(../Images/ajax-loader.gif) no-repeat center center;
   height: 100px;
   width: 100px;
   position: fixed;
   z-index: 1000;
   left: 50%;
   top: 50%;
   right:50%;
   bottom:50%;
   margin: -25px 0 0 -25px;
}

</style>
<script>
$(window).load(function(){
  $('#dvLoading').fadeOut(2000);
});
</script>



<div id="dvLoading"><?php echo '<meta http-equiv="refresh" content="2;url=index.php">'; ?></div>

