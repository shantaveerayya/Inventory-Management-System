<?php
include ("../connection.php");


	if (!isset($_FILES['image']['tmp_name']))
	 {
	  echo "";
	 }
	else
	 {
	   $file=$_FILES['image']['tmp_name'];
	   $image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	   $image_name= addslashes($_FILES['image']['name']);
	   $image_size= getimagesize($_FILES['image']['tmp_name']);

	
		if ($image_size==FALSE)
		  {
			echo "That's not an image!";
		  }
		else
		  {
			
			move_uploaded_file($_FILES["image"]["tmp_name"],"../../inventorySystem/Admin/Image/" . $_FILES["image"]["name"]);
			
$location =$_FILES["image"]["name"];
$description = $_REQUEST['description'];
$unit = $_REQUEST['unit'];
$date = $_REQUEST['date1'];
$qty = $_REQUEST['qty'];
$unitcost = $_REQUEST['unitcost'];

$check = mysql_query("SELECT * FROM tblsupply WHERE description='$description'");

$do_check = mysql_num_rows($check);

//Now display errors


if($do_check > 0){

die($description . " " .  "is already in use!<br>");

}


$insert = mysql_query("INSERT INTO tblsupply (id, img, description, unit, date, quantity, unitcost ) VALUES ('', '$location', '$description', '$unit', '$date', '$qty', '$unitcost')");

if(!$insert){

die("There's little problem: ".mysql_error());

}

include("loading.php");
echo '<meta http-equiv="refresh" content="1;url=supply.php">';
}
}
?>