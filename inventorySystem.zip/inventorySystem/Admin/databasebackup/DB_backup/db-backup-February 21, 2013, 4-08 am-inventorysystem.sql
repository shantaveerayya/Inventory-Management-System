

CREATE TABLE `division` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `division` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO division VALUES("29","ADMINISTRATIVE AND FINANCE ");
INSERT INTO division VALUES("30","PMED");





CREATE TABLE `employee` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `mi` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `division` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO employee VALUES("14","jameel","basher","a","maura","PMED");
INSERT INTO employee VALUES("15","angel","encarnacon","f","aaaa","ADMINISTRATIVE AND FINANC");
INSERT INTO employee VALUES("18","gfdg","gfd","gfd","gfdg","ADMINISTRATIVE AND FINANC");
INSERT INTO employee VALUES("20","hgfh","gfh","hgf","ew","PMED");
INSERT INTO employee VALUES("21","xds","fsdf","fsdf","fsdf","PMED");
INSERT INTO employee VALUES("23","dasd","dasd","dasds","dsd","ADMINISTRATIVE AND FINANC");
INSERT INTO employee VALUES("24","fds","fsd","fsdf","fsdf","ADMINISTRATIVE AND FINANC");





CREATE TABLE `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `session` (
  `session_id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `session_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO session VALUES("4","jameel","2013-02-21 11:17:32");
INSERT INTO session VALUES("7","jaleel","2013-01-13 20:47:01");
INSERT INTO session VALUES("8","boniejane","2013-01-13 20:40:43");
INSERT INTO session VALUES("9","jasmin","2013-01-13 20:48:03");
INSERT INTO session VALUES("10","carmen","2013-01-15 20:55:11");
INSERT INTO session VALUES("12","jerick","2013-01-20 17:07:52");





CREATE TABLE `tblrequest` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `division` varchar(50) NOT NULL,
  `description` varchar(40) NOT NULL,
  `unitcost` varchar(15) NOT NULL,
  `unit` varchar(15) NOT NULL,
  `qty` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=latin1;

INSERT INTO tblrequest VALUES("197","aaa","12/2/2012","ADMINISTRATIVE AND FINANCE ","bond","P108","ream","3");
INSERT INTO tblrequest VALUES("198","aaa","12/2/2012","ADMINISTRATIVE AND FINANCE ","aaa","P4.5","aaa","3");





CREATE TABLE `tblsupply` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `img` varchar(35) NOT NULL,
  `description` varchar(30) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `unitcost` float NOT NULL,
  `date` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

INSERT INTO tblsupply VALUES("66","add.png","aaaa","sa","3","3","02/05/2013");
INSERT INTO tblsupply VALUES("67","amuni.jpg","bbbb","ffff","5","5","02/05/2013");
INSERT INTO tblsupply VALUES("68","edit.gif","ccccc","ccc","50","5","02/05/2013");





CREATE TABLE `tbluser` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

INSERT INTO tbluser VALUES("41","Jameel","Bashers","Jameel","jameel","admin","1");



