

CREATE TABLE `division` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `division` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO division VALUES("29","ADMINISTRATIVE AND FINANCE ");
INSERT INTO division VALUES("30","PMED");
INSERT INTO division VALUES("31","FINANCE");





CREATE TABLE `employee` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `mi` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `division` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO employee VALUES("14","jameel","basher","a","maura","PMED");
INSERT INTO employee VALUES("15","angel","encarnacon","f","aaaa","ADMINISTRATIVE AND FINANC");
INSERT INTO employee VALUES("18","gfdg","gfd","gfd","gfdg","ADMINISTRATIVE AND FINANC");
INSERT INTO employee VALUES("20","hgfh","gfh","hgf","ew","PMED");
INSERT INTO employee VALUES("21","xds","fsdf","fsdf","fsdf","PMED");
INSERT INTO employee VALUES("23","dasd","dasd","dasds","dsd","ADMINISTRATIVE AND FINANC");
INSERT INTO employee VALUES("24","fds","fsd","fsdf","fsdf","ADMINISTRATIVE AND FINANC");





CREATE TABLE `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `session` (
  `session_id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `session_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO session VALUES("4","jameel","2013-03-08 09:32:29");
INSERT INTO session VALUES("7","jaleel","2013-01-13 20:47:01");
INSERT INTO session VALUES("8","boniejane","2013-01-13 20:40:43");
INSERT INTO session VALUES("9","jasmin","2013-01-13 20:48:03");
INSERT INTO session VALUES("10","carmen","2013-01-15 20:55:11");
INSERT INTO session VALUES("12","jerick","2013-01-20 17:07:52");
INSERT INTO session VALUES("13","basher","2013-02-25 16:20:03");





CREATE TABLE `tblrequest` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `division` varchar(50) NOT NULL,
  `description` varchar(40) NOT NULL,
  `unitcost` varchar(15) NOT NULL,
  `unit` varchar(15) NOT NULL,
  `qty` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=latin1;

INSERT INTO tblrequest VALUES("197","aaa","12/2/2012","ADMINISTRATIVE AND FINANCE ","bond","P108","ream","3");
INSERT INTO tblrequest VALUES("198","aaa","12/2/2012","ADMINISTRATIVE AND FINANCE ","aaa","P4.5","aaa","3");
INSERT INTO tblrequest VALUES("199","Jameel","02/22/13","PMED","Bond Paper","P100","ream","0");
INSERT INTO tblrequest VALUES("200","Jameel","02/22/13","PMED","pencil","P5","pc","0");
INSERT INTO tblrequest VALUES("201","Jameel","02/22/13","PMED","ballpen","P4","pc","0");
INSERT INTO tblrequest VALUES("202","Jameel","02/22/13","PMED","computer","P30000","unit","0");





CREATE TABLE `tblsupply` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `img` varchar(35) NOT NULL,
  `description` varchar(30) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `unitcost` float NOT NULL,
  `date` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

INSERT INTO tblsupply VALUES("69","addSupply.png","Bond Paper","ream","50","100","02/06/2013");
INSERT INTO tblsupply VALUES("70","arrow_refresh.png","pencil","pc","100","5","02/22/2013");
INSERT INTO tblsupply VALUES("71","cancel.png","ballpen","pc","50","4","02/21/2013");
INSERT INTO tblsupply VALUES("72","8500.jpg","computer","unit","5","30000","02/21/2013");
INSERT INTO tblsupply VALUES("73","books.png","books","pc","5","50","02/14/2013");
INSERT INTO tblsupply VALUES("74","flash-disk.jpg","usb","pc","10","350","02/22/2013");
INSERT INTO tblsupply VALUES("75","accurist-3952-72583-1-catalog.jpg","clock","1","5","100","02/21/2013");





CREATE TABLE `tbluser` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO tbluser VALUES("41","Jameel","Bashers","Jameel","jameel","admin","1");
INSERT INTO tbluser VALUES("42","Jaleel","basher","jaleel","jaleel","FINANCE","1");
INSERT INTO tbluser VALUES("43","Jameel","basher","basher","031990","FINANCE","1");



