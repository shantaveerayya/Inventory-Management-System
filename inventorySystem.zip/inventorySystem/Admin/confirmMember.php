<?php
include('../connection.php');
$id =$_REQUEST['id'];

	mysql_query("UPDATE tbluser SET confirmation ='1' WHERE id = '$id'")
				or die(mysql_error()); 
				
	echo"Save!";
	
	header("Location: userReg.php");			

mysql_close($conn);
?>