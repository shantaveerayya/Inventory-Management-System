<?php
  include("../connection.php");  

	$id = $_REQUEST['id'];
	//$quantity = $_REQUEST['quantity'];
	
	//$upd=mysql_query("UPDATE tblorders SET quantity= '$quantity' WHERE id = '$id'")
	//or die(mysql_error());
	// sending query
	$del = mysql_query("DELETE FROM tblorders WHERE id = '$id'")
	or die(mysql_error()); 

	header("Location: orderPlaced.php");
?>