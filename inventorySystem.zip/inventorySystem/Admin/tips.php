<?php

include('../connection.php');

if(!$_POST['img']) die("There is no such product!");

$img=mysql_real_escape_string(end(explode('/',$_POST['img'])));

$row=mysql_fetch_assoc(mysql_query("SELECT * FROM tblsupply WHERE img='".$img."'"));

if(!$row) die("There is no such product!");

echo '<strong>'.$row['description'].'</strong>

<p class="descr">'.$row['description'].'</p>

<strong>price: $'.$row['unitcost'].'</strong>
<small>Drag it to your shopping cart to purchase it</small>';
?>
