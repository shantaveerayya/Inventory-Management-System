<?php
session_start();

if (!isset($_SESSION['username']))
  {
    header('Location: ../index.php');
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Inventory System</title>
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />

<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script type="text/javascript" language="javascript">
function validateTextBox(){
var form=document.getElementById("viewSup");
var desc=form["desc"].value;
var unt=form["unit"].value;
var qty=form["qty"].value;
var cost=form["cost"].value;
var date=form["date"].value;
var desc_err=document.getElementById("desc_err");
var unit_err=document.getElementById("unit_err");
var qty_err=document.getElementById("qty_err");
var cost_err=document.getElementById("cost_err");
var date_err=document.getElementById("date_err");
if(desc==""){
desc_err.innerHTML="Desciption is empty!";
}else{
desc_err.innerHTML="";
}
if(unt==""){
unit_err.innerHTML="Unit is empty!";
}else{
unit_err.innerHTML="";
}

if(qty==""){
qty_err.innerHTML="Quantity is empty!";
}else{
qty_err.innerHTML="";
}
if(cost==""){
cost_err.innerHTML="Cost is empty!";
}else{
cost_err.innerHTML="";
}
if(date==""){
date_err.innerHTML="Date is empty!";
}else{
date_err.innerHTML="";
}

if(desc=="" || unt=="" || qty=="" || cost=="" || date==""){
alert("Please fill all required fields!");
return false
}else{
return true;
}
}
</script>
<script>
function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>
</head>

<body onload="startTime()">
 <center>
  <?php include("../menu.php"); ?>
 </center>
 
  <center>
   <?php include("../header.php"); ?>
  </center>
  
   <center>
      <div class="home">
	    <div class="homeTop">
		 <div class="homeTopLeft">
		  <p class="menu">QUICK MENU</p>
		 </div>
		 
		 <div class="homeTopRight">
		   <div class="ucUser">
		  <a href="memberConfirmation.php">
		    <div class="ucUser2">
		     <?php
		   include("../connection.php");
$result = mysql_query("SELECT * FROM tbluser WHERE confirmation='0'");
	
	$numberOfRows = MYSQL_NUMROWS($result);	
	  if($numberOfRows > 0)
	  {
	    echo '<p class="ucUser"><b>(' . $numberOfRows .')</b></p>';
	  } 
	  else
	   {
	    echo '<p class="ucUser"></p>';
	   }
	  ?>
			</div>
		    <div class="ucUser1">
		    <img src="../Images/user.png" class="ucUser"/>
			</div>
		</a> 
	
		   </div>
		 </div>
		</div>
		
		<div class="homeMenu">
		  <div class="homeBox">
		   <a href="addDiv.php" style="text-decoration:none"><img src="../Images/chart_organisation.png" class="menu" />
		   <p class="menuButton">DIVISION</p></a>
		  </div>
		  <div class="homeBox">
		   <a href="employee.php" style="text-decoration:none"><img src="../Images/group_gear.png" class="menu" />
		   <p class="menuButton">EMPLOYEE MANAGEMENT</p></a>
		  </div>
		  <div class="homeBox">
 		   <a href="userReg.php" style="text-decoration:none"><img src="../Images/Users.png" class="menu" />
		    <p class="menuButton">USER MANAGEMENT</p></a>
		  </div>
		  <div class="homeBox">
		   <a href="supply.php" style="text-decoration:none"><img src="../Images/lorry.png" class="menu" />
		   <p class="menuButton">STOCK</p></a>
		  </div>
		  <div class="homeBox">
		   <a href="Request/request.php" style="text-decoration:none"><img src="../Images/package_go.png" class="menu" />
		   <p class="menuButton">REQUEST ITEMS</p></a>
		  </div>
		</div> 
		
		<div class="homeMenu">
		  <!--<div class="homeBox">
		   <a href="databasebackup/backup.php" style="text-decoration:none"><img src="../Images/database_save.png" class="menu" />
   		   <p class="menuButton">BACKUP DATABASE</p></a>
		  </div>
		  <div class="homeBox">
		   <a href="usersLog.php" style="text-decoration:none"><img src="../Images/diagramm.png" class="menu" />
   		   <p class="menuButton">USER'S LOG</p></a>
		  </div>-->
		  <div class="homeBox">
 		   <a href="reqSupply.php" style="text-decoration:none"><img src="../Images/newuser.png" class="menu" />
		   <p class="menuButton">REQUESTED ITEMS</p></a>
		  </div>
		  <div class="homeBox">
		   <a href="orderPlaced.php" style="text-decoration:none"><img src="../Images/package_go.png" class="menu" />
		   <p class="menuButton">PLACED ORDERS</p></a>
		  </div>
		  <div class="homeBox">
		   <a href="preview.php" style="text-decoration:none"><img src="../Images/document_copies.png" class="menu" />
		   <p class="menuButton">REPORTS</p></a>
		  </div>
		 
		  <!--<div class="homeBox">
		   <a href="reorder.php" style="text-decoration:none"><img src="../Images/cancel.png" class="menu" />
		   <p class="menuButton">SUPPLIES W/IN REORDER POINT</p></a>
		  </div>-->
		</div> 
		
		<div class="homeMenu">
		  <div class="homeBox">
		   <a href="logout.php" style="text-decoration:none"><img src="../Images/cancel.png" class="menu" />
		   <p class="menuButton">LOG-OUT</p></a>
		  </div>
		</div> 
		
		<div class="homeRight">
		     
		</div> 
	  </div>
   </center> 
   
  
  <center>
   <?php include("../footer.php"); ?>  
  </center>
</body>
</html>