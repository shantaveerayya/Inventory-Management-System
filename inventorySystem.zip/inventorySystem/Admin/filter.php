<style type="text/css">
table
 {
  width:770px;
 }
 
td
 {
 font-family:Geneva, Arial, Helvetica, sans-serif;
 font-size:13px;
 text-transform:uppercase;
 border:1px solid #666666;
 }

thead
 {
  font-weight:bold;
 }
 
div.head
 {
  width:780px;
  height:150px;
  margin-bottom:1px;
  margin-top:50px;
  text-align:center;
 }
 
div.footer
 {
  width:780px;
  height:150px;
  margin-top:50px;
 }
 
p.head
 {
  font-family:Arial, Helvetica, sans-serif;
  font-size:12px;
  line-height:3px;
 }
 
p.footer
 {
  font-family:Arial, Helvetica, sans-serif;
  font-size:12px;
  line-height:3px;
  text-align:left;
 }

 
p.headBold
 {
  font-family:Arial, Helvetica, sans-serif;
  font-size:14px;
  line-height:3px;
 }
 
p.headTitle
 {
  font-family:Arial, Helvetica, sans-serif;
  font-size:18px;
  line-height:3px;
 }
 
div.left
 {
  height:150px;
  width:380px;
  float:left;
 }
div.Right
 {
  height:150px;
  width:380px;
  float:right;
 }

</style>
<center>
<div class="head">
 <p class="head">Republic of the Philippines</p>
 <p class="headBold"><b>BUREAU OF FISHERIES AND AQUATIC RESOURCES</b></p>
 <p class="head">Regional Office II</p>
 <br />
 <p class="headTitle"><b>INVENTORY REPORT</b></p>
</div>
<table>
			<?php
			include('../connection.php');
			//include("session.php");
			
			$a=$_POST['from'];
            $b=$_POST['to'];

            $result = mysql_query("SELECT * FROM tblsupply  where date BETWEEN '$a' AND '$b'");

			echo"<thead>";
			echo"<tr>
			       <td width='220'>Description</th>
   			       <td width='90'  align='center'>Unit</th>
				   <td width='70'  align='center'>Date Purchased</th>
				   <td width='50'  align='center'>Qty</th>
  				   <td width='80'  align='center'>Unit Cost</th>
			    </tr>";
			echo"</thead>";
			
			while($test = mysql_fetch_array($result))
			{				
					echo "<tr>";	
					echo"<td >" .$test['description']."</td>";
					echo"<td  align='center'>". $test['unit']. "</td>";
					echo"<td  align='center'>". $test['date']. "</td>";
					echo"<td  align='center'>". $test['quantity']. "</td>";	
					echo"<td  align='center'>". $test['unitcost']. "</td>";					
					echo "</tr>";
				
			}		
				
			mysql_close($conn);
			?>
</table>
<div class="footer">
 <div class="left">
   <p class="footer">Prepared by:</p><br />
   <p class="footer"><b>JUANITO T. DOMINGO</b></p>
   <p class="footer">Supply Officer</p>
 </div>
 <div class="Right">
   <p class="footer">Approved by:</p><br />
   <p class="footer"><b>JOVITA P. AYSON, DrFT, CESO II</b></p>
   <p class="footer">Regional Director</p>
 </div>
</div>
</center>