<?php
include ("../connection.php");
$div = $_REQUEST['div'];

$div_check = mysql_query("SELECT division FROM division WHERE division='$div'");

$do_div_check = mysql_num_rows($div_check);

//Now display errors


if($do_div_check > 0){

die($div . " " . "is already in use!<br>");

}


$insert = mysql_query("INSERT INTO division (id, division) VALUES ('', '$div')");

if(!$insert){

die("There's little problem: ".mysql_error());

}

include("loading.php");
echo '<meta http-equiv="refresh" content="1;url=addDiv.php">';
//echo "<a href='adddivisions.php'>back</a>";
?>


