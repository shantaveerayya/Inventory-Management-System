<center>
<table border="0" height="500" width="950">
<tr>
<td align="center">
<?php

// Inialize session
session_start();

// Delete certain session
unset($_SESSION['username']);
// Delete all session variables
// session_destroy();

 echo '<meta http-equiv="refresh" content="2;url= ../index.php">';
 echo'<span><font size="5" color="#337033">Logging out please wait...</font><br><img width="60" height="60" src="../Images/ajax-loader.gif"></span>';


// Jump to login page
//header('Location: index.php');

?>
</td>
</tr>
</table>
</center>
