<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Supply Management</title>
<script src="../filter/app.js" type="text/javascript" charset="utf-8"></script>
<script src="../filter/application.js" type="text/javascript" charset="utf-8"></script>

<!--box -->
<script language="javascript" src="../lib/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="../facebox/facebox.css" />

<script language="javascript" src="../facebox/facebox.js"></script>

<script language="javascript">
jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'facebox/loading.gif',
    
      })
    })
</script>
<!--endbox -->
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
<link rel="stylesheet" type="text/css" href="../CSS/modalWindow.css" />

<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script>
function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>
</head>

<body onload="startTime()">
 <center>
  <?php include("../menu.php"); ?>
 </center>
 
  <center>
   <?php include("../header.php"); ?>
  </center>
  
   <center>
     <div class="supply">
	   <div class="employeeHead">
	   
	    <div class="empTopLeft">
		 <div class="searchContainer1">
         <img src="../Images/google_custom_search.png" class="search1" />
         <input type="text" size="45" class="search1" placeholder="SEARCH..." name="filter" value="" id="filter"/>
		 <p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#00CC33;"></p>
         </div>
		</div>
		
		<div class="empTopRight"> 
		</div>		
	   </div>
	   
	   <div class="supCont">
	   
       <div class="viewSupt">
      <table style="text-transform:uppercase">
			<?php
			include('../connection.php');
			//include("session.php");
			
			$result=mysql_query("SELECT * FROM tblsupply ORDER BY description");
			
			$color = "1";

			echo"<form method='post' name='form' id='form' action='delmultipleSupply.php' onsubmit='return confirmdelete();'>";
			echo"<thead>";
			echo"<tr class='empHead'>
			       <td width='40' align='center'><input  id='delete' type='submit' name='delete' value='x'/></th>
				   <td width='80' align='center'>Image</th>
			       <td width='210'>Description</th>
   			       
				   <td width='80' align='center'>Date Purchased</th>
				   <td width='50' align='center'>Qty</th>
  				   <td width='80' align='center'>Unit Cost</th>
				   <td width='70' align='center'><center>Add</certer></th>
				   <td width='70' align='center'><center>Edit</certer></th>
				   <td width='70' align='center'><center>Delete</center></th>
			    </tr>";
			echo"</thead>";
			
			while($test = mysql_fetch_array($result))
			{
				if($color==1)
				 
				 {
				
					$id = $test['id'];	
					
					echo "<tr class='View1emp'>";	
					echo"<td  align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo '<td align="center"><a rel="facebox" href="editImage.php?id='.$test['id'].'"><img src="../../inventorySystem/Admin/Image/'.$test['img'].'" width="60" height="30"></a></td>';
					echo"<td>" .$test['description']."</td>";
					
					echo"<td align='center'>". $test['date']. "</td>";
					echo"<td align='center'>". $test['quantity']. "</td>";	
					echo"<td align='center'>". $test['unitcost']. "</td>";	
					echo"<td> <a href='addSupplyQU.php?id=$id'' rel='facebox'><center><img class='editdelete' src='../Images/add.png' /></center></a></td>";
					echo"<td> <a href='editSupply.php?id=$id' rel='facebox'><center><img class='editdelete' src='../Images/edit.png' /></center></a></td>";
					echo"<td width='70'><a href ='delSupply.php?id=$id'><center><img class='editdelete'  src='../Images/delete.png' onclick='return confirmdelete();'/></center></a></td>";					
					echo "</tr>";
				
					
					$color = "2";
				 }
				 
				 else
				 
				 {
					 $id = $test['id'];	
				
					echo "<tr class='View2emp'>";	
					echo"<td width='50' align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo '<td align="center"><a rel="facebox" href="editImage.php?id='.$test['id'].'"><img src="../../inventorySystem/Admin/Image/'.$test['img'].'" width="60" height="30"></a></td>';
					echo"<td>" .$test['description']."</td>";
					//echo"<td align='center'>". $test['unit']. "</td>";
					echo"<td align='center'>". $test['date']. "</td>";
					echo"<td align='center'>". $test['quantity']. "</td>";	
					echo"<td align='center'>". $test['unitcost']. "</td>";	
					echo"<td> <a href='addSupplyQU.php?id=$id'' rel='facebox'><center><img class='editdelete' src='../Images/add.png' /></center></a></td>";
					echo"<td> <a href='editSupply.php?id=$id' rel='facebox'><center><img class='editdelete' src='../Images/edit.png' /></center></a></td>";
					echo"<td width='70'><a href ='delSupply.php?id=$id'><center><img class='editdelete'  src='../Images/delete.png' onclick='return confirmdelete();'/></center></a></td>";					
					echo "</tr>";
					
					$color = "1";
				 }
				 
			}
			
			echo"</form>";
			mysql_close($conn);
			?>
</table>
   </div>
	   </div>
	   <div class="supContRight">
	     <div class="imgContRight">
		  <div class="homeBox1">
		   <a href="addSupply.php" rel="facebox"><img src="../Images/addSupply.png" class="menu" /></a>
		   <p class="menuButton">ADD</p>
		  </div>
		 </div>
		 
		  <div class="imgContRight">
		   <div class="homeBox1">
		    <a href="Request/request.php"><img src="../Images/arrow_rotate_clockwise.png" class="menu" /></a>
		    <p class="menuButton">REQUEST</p>
		   </div>
		 </div>
		 
		 <div class="imgContRight">
		   <div class="homeBox1">
		    <a href="addOrder.php" rel="facebox"><img src="../Images/addSupply.png" class="menu" /></a>
		    <p class="menuButton">ORDER</p>
		   </div>
		 </div>
		 
		 <div class="imgContRight">
		  <div class="homeBox1">
		   <a href="supply.php"><img src="../Images/arrow_refresh.png" class="menu" /></a>
		   <p class="menuButton">REFRESH</p>
		  </div>
		 </div>
		 
		  <div class="imgContRight">
		   <div class="homeBox1">
		    <a href="" rel="facebox"><img src="../Images/arrow_undo.png" class="menu" /></a>
		    <p class="menuButton">LOG-OUT</p>
		   </div>
		 </div>
		 
	   </div>
	   
	 </div>
   </center> 
   
  
  <center>
   <?php include("../footer.php"); ?>  
  </center>
</body>
</html>