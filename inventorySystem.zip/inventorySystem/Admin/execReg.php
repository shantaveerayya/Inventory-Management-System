<?php
include("../connection.php");

$fname = $_REQUEST['firstname'];

$lname = $_REQUEST['lastname'];

$username = $_REQUEST['username'];

$password = $_REQUEST['password'];

$repass = $_REQUEST['repassword'];

$type = $_REQUEST['type'];
 


$user_check = mysql_query("SELECT username FROM tbluser WHERE username='$username'");

$do_user_check = mysql_num_rows($user_check);

//Now display errors


if($do_user_check > 0){

die($username . " " . "is already in use!<br>");

}


$insert = mysql_query("INSERT INTO tbluser (id, firstname, lastname, username, password, type) VALUES ('', '$fname', '$lname', '$username', '$password', '$type')");

if(!$insert){

die("There's little problem: ".mysql_error());

}

include("loading.php");
echo '<meta http-equiv="refresh" content="1;url=userReg.php">';

?>