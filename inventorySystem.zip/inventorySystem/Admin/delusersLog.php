<?php
  include("../connection.php");  

	$id =$_REQUEST['session_id'];
	
	
	// sending query
	$del = mysql_query("DELETE FROM session WHERE session_id = '$id'")
	or die(mysql_error()); 

	header("Location: usersLog.php");
?>