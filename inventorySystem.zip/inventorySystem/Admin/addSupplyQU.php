 <link rel="stylesheet" href="../Date/jquery-ui.css"/>
 <script src="../Date/jquery1.js"></script>
 <script src="../Date/jquery2.js"></script>
 
<script type="text/javascript">
<!--
function Checker(string) {
value_entered = string ;
if (isNaN(value_entered)) {
window.alert("Only Numbers are allowed in these fields");
return false; }
}

function Total1(element) {
 if (Checker(element.value)==false){
   element.focus();
   element.select();
   return false;
 }

var t1a=Form1.entry1a.value;
var t1b=Form1.entry1b.value;
var t2a=Form1.entry2a.value;
var t2b=Form1.entry2b.value;

if(t1a =="") { t1a = 0; }
if(t1b =="") { t1b = 0; }
if(t2a =="") { t2a = 0; }
if(t2b =="") { t2b = 0; }

Form1.sum1.value = parseInt(t1a) * parseInt(t1b);
Form1.sum2.value = parseInt(t2a) * parseInt(t2b);
Form1.sum3.value = parseInt(Form1.sum1.value) + parseInt(Form1.sum2.value);
Form1.sum4.value = parseInt(t1a) + parseInt(t2a);
Form1.sum5.value = parseInt(Form1.sum3.value) / parseInt(Form1.sum4.value);

}

function checkFocus(string){
 if (string != "" && Checker(string)==false) {
   event.srcElement.focus();
   return false;
 }
}
//-->
</script>
 <script>
    $(function() {
        $( "#datepicker" ).datepicker();
    });
 </script>
	
<script type="text/javascript">
function validateForm()
{
var a=document.forms["addSup"]["description"].value;
if (a==null || a=="")
  {
  alert("Description is empty!");
  return false;
  }
var b=document.forms["addSup"]["unit"].value;
if (b==null || b=="")
  {
  alert("Unit is emplty!");
  return false;
  }
 var c=document.forms["addSup"]["date"].value;
if (c==null || c=="")
  {
  alert("Date is empty!");
  return false;
  }
var d=document.forms["addSup"]["qty"].value;
if (d==null || d=="")
  {
  alert("Quantity is empty!");
  return false;
  }
 var e=document.forms["addSup"]["unitcost"].value;
if (e==null || e=="")
  {
  alert("Unit Cost is empty!");
  return false;
  }
}
</script>
<SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>
   
		
<link rel="stylesheet" type="text/css" href="../CSS/general.css"/>
<link rel="stylesheet" type="text/css" href="../CSS/modalWindow.css"/>

<div class="modConAdd">
 <center>
   <div class="modHeaderAdd">
    <h3 class="modalHeader">
    ADD SUPPLY
    </h3>
   </div>
 <form action="execAddSupplyQU.php" method="post" enctype="multipart/form-data" name="Form1" onsubmit="return validateForm()">  
   <div class="modContentAdd">
    <div class="Row1Add">
	  
	  <table border="0" width="250">
	   <tr>
	     <td width="350">
		  Quanity
		 </td>
		 <td width="">
		  Unit Cost
		 </td>
	   </tr>
	   
	   <tr>
	     <td width="310">
		  <input id="num1" class="modText"  name="entry1a" onChange="return Total1(this)" size="15">      
		 </td>
		 <td>
		  <input id="num2" class="modText"  name="entry1b" onChange="return Total1(this)" size="15">
		 </td>
		 
		 <td>
		  <input type="hidden" id="num3" class="modText"  name="sum1" size="15">
		 </td>
	   </tr>
	   
	   <tr>
	    <td>
		 Date Purchased
		</td>
	   </tr>
	   
	   <tr>
	    <td>
		 <input type="text" id="datepicker" class="modText" size="15" name="date1" readonly="readonly"/>
		</td>
	   </tr>
	   
	    <tr>
	     <td width="310">
		 <?php
			include('../connection.php');
			$id =$_REQUEST['id'];
					
			$result=mysql_query("SELECT * FROM tblsupply WHERE id = '$id'");
			while($test = mysql_fetch_array($result))
			 {
			 $id = $test['quantity'];	
             $uc = $test['unitcost'];
			 $desc = $test['description'];
			 $unit = $test['unit'];
			 $date = $test['date'];	
			 $idd = $test['id'];	
			 }
		 ?>	
		   <input id="num1" type="hidden" class="modText"  name="entry2a" onChange="return Total1(this)" size="15" value="<?php echo $id ?>" s>
		 </td>
		 <td>
		   <input id="num2" type="hidden"  class="modText"  name="entry2b" onChange="return Total1(this)" size="15" value="<?php echo $uc ?>">
		 </td>
		 
		 <td>
		  <input id="num3" type="hidden"  class="modText"  name="sum2" size="15">
		 </td>
	   </tr>
	   
	    <tr>
		 <td width="310">
		  <input id="num1" type="hidden" class="modText"  name="sum4" onChange="return Total1(this)" size="15">      
		 </td>	    
		</tr>
		
		<tr>		 
	     <td width="310">
		  <input id="num1" type="hidden"  class="modText"  name="sum3" onChange="return Total1(this)" size="15">      
		 </td>
		</tr>
		
		<tr>		 
	     <td width="310">
		  <input id="num1" type="hidden"  class="modText"  name="sum5" onChange="return Total1(this)" size="15">      
		 </td>
		</tr>
		
		<tr>
		
	     <td width="310">
		  <input id="num1" type="hidden"  class="modText"  name="desc"  size="15" value="<?php echo $desc ?>">      
		 </td>
		 <td width="310">
		  <input id="num1" type="hidden"  class="modText"  name="unit"  size="15" value="<?php echo $unit ?>">      
		 </td>
		 <td width="310">
		  <input id="num1" type="hidden"  class="modText"  name="date"  size="15" value="<?php echo $date ?>">       
		 </td>
		</tr>
		
		<tr>
		 <td width="310">
		  <input id="num1" type="hidden"  class="modText"  name="id"  size="15" value="<?php echo $idd ?>">      
		 </td>	
		 </tr>
	   
	   
	   
	   <tr>
	    <td height="2">
		 <input type="submit" name="submit" value="save" class="button" style="margin-top:-15px; margin-left:1px;"/>
		</td>
	   </tr>	  
	  </table>
	   	
   </div>
  </form>
 </center>
</div>