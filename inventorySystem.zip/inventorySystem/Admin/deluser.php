<?php
  include("../connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	$del = mysql_query("DELETE FROM tbluser WHERE id = '$id'")
	or die(mysql_error()); 

	header("Location: userReg.php");
?>