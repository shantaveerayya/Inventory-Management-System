<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User Registration</title>
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script language="javascript">
function CountLeft(field, count, max) {
if (field.value.length > max)
field.value = field.value.substring(0, max);
else
count.value = max - field.value.length;
}
</script>
<script type="text/javascript" language="javascript">

function validateTextBox(){
var form=document.getElementById("userReg");
var fname=form["firstname"].value;
var lname=form["lastname"].value;
var username=form["username"].value;
var password=form["password"].value;
var repassword=form["repassword"].value;
var fn_err=document.getElementById("fn_err");
var ln_err=document.getElementById("ln_err");
var un_err=document.getElementById("un_err");
var pass_err=document.getElementById("pw_err");
var repass_err=document.getElementById("rpw_err");
if(fname==""){
fn_err.innerHTML="Firstname is empty!";
}else{
fn_err.innerHTML="";
}
if(lname==""){
ln_err.innerHTML="Lastname is empty!";
}else{
ln_err.innerHTML="";
}
if(username==""){
un_err.innerHTML="Username is empty!";
}else{
un_err.innerHTML="";
}
if(password==""){
pass_err.innerHTML="Password is empty!";
}else{
pass_err.innerHTML="";
}
if(repassword==""){
repass_err.innerHTML="Re-type Password is empty!";
}else{
repass_err.innerHTML="";
}
if (username.length < 6) {
  alert('Please enter a username that is at least 6 characters long');	
  return false;
}
if (password.length < 6) {
  alert('Please enter a password that is at least 6 characters long');	
  return false;
}
if (form.password.value != form.repassword.value) {
  alert('Your password and confirmation password did not much!');	
  return false;
}
if(fname=="" || lname=="" || username=="" || password=="" || repassword==""){
alert("Please fill all required fields!");
return false
}else{
return true;
}
}
</script>
<script>
function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>
</head>

<body onload="startTime()">
 <center>
  <?php include("../menuMember.php"); ?>
 </center>
 
  <center>
   <?php include("../header.php"); ?>
  </center>
  
  <center>
   <div class="mainContainerUserReg">
     <div class="userRegTop">
      <div class="userRegHeaderIcon">
       <img src="../Images/newuser.png" class="userReg" />
      </div>
      <div class="userRegHeaderText">
       <p class="userReg">MEMBERS'S REGISTRATION</p>
      </div>
     </div>
     
     <div class="userRegLeft">
     <form name="userReg" id="userReg" method="post" action="execRegmember.php" onsubmit="javascript:return validateTextBox();">
            <div class="Label">FIRSTNAME</div>
            <div id="fn_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:               20px; margin-left:5px;">
            </div>
            <div class="Text">
           <input class="Text" type="text" tabindex="1" name="firstname" value="" size="19" onKeyDown=             "CountLeft(this.form.firstname, this.form.fname,30);" onKeyUp="CountLeft(this.form.firstname,this.form.fname,30);"/>
            <input readonly type="text" name="fname" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">   
            </div>
            <div class="Label">LASTNAME</div><div id="ln_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" tabindex="2" type="text" value="" name="lastname" size="19" onKeyDown=             "CountLeft(this.form.lastname, this.form.lname,30);" onKeyUp="CountLeft(this.form.lastname,this.form.lname,30);"/>
           <input readonly type="text" name="lname" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">   
            </div>
            <div class="Label">USERNAME</div> 
            <div id="un_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px;">
            </div>
            <div class="Text"><input class="Text" type="text" tabindex="3" value="" name="username" size="19"  onKeyDown=             "CountLeft(this.form.username, this.form.uname,30);" onKeyUp="CountLeft(this.form.username,this.form.uname,30);"/> <input readonly type="text" name="uname" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">   
            </div>       
            <div class="Label">PASSWORD</div>
            <div id="pw_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" type="password" tabindex="4" name="password" size="19" onKeyDown=             "CountLeft(this.form.password, this.form.pword,30);" onKeyUp="CountLeft(this.form.password,this.form.pword,30);"/><input readonly type="text" name="pword" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">
            </div>
            
            <div class="Label">RE-TYPE PASSWORD</div>
            <div id="rpw_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" type="password" tabindex="4" name="repassword" size="19" onKeyDown=             "CountLeft(this.form.repassword, this.form.repword,30);" onKeyUp="CountLeft(this.form.repassword,this.form.repword,30);"/><input readonly type="text" name="repword" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">
            </div>
            
            <div class="Label">TYPE</div>
          <div class="Text">
           <label>
        <select name="type" id="userType">
         <?php
		   include("../connection.php");
           $query_disp="SELECT * FROM division order by division asc";
           $result_disp = mysql_query($query_disp);
            while($query_data = mysql_fetch_array($result_disp))
              {
          ?>
<option value="<?php echo $query_data['division']; ?>"><?php echo $query_data['division']; ?></option>
<?php } ?>
      </select>

      </label>
          </div>
          <div class="loginButton"><input  class="button" type="submit" name="submit" value="Register" /></div>        
          </form>
     </div>
      <div class="userRegRight">
       <div class="viewuser">
         
       </div>
     </div>
     
   </div>
  </center>
  
  <center>
   <?php include("../footer.php"); ?>  
  </center>
</body>
</html>