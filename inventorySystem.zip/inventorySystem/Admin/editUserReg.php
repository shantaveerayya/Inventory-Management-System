<?php
include('../connection.php');
$id =$_REQUEST['id'];

$result = mysql_query("SELECT * FROM tbluser WHERE id  = '$id'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$firstname=$test['firstname'] ;
				$lastname= $test['lastname'] ;					
				$username=$test['username'] ;
				$password=$test['password'] ;
				$type = $test['type'];

if(isset($_POST['submit']))
{	

	$firstname_save = $_POST['firstname'];
	$lastname_save = $_POST['lastname'];
	$username_save = $_POST['username'];
	$password_save = $_POST['password'];
	$type_save = $_POST['type'];

	mysql_query("UPDATE tbluser SET firstname ='$firstname_save', lastname ='$lastname_save',
		 username ='$username_save',password ='$password_save', type ='$type_save' WHERE id = '$id'")
				or die(mysql_error()); 
				
	echo"Save!";
	
	header("Location: userReg.php");			
}
mysql_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User Registration</title>
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script language="javascript">
function CountLeft(field, count, max) {
if (field.value.length > max)
field.value = field.value.substring(0, max);
else
count.value = max - field.value.length;
}
</script>
<script type="text/javascript" language="javascript">

function validateTextBox(){
var form=document.getElementById("userReg");
var fname=form["firstname"].value;
var lname=form["lastname"].value;
var username=form["username"].value;
var password=form["password"].value;
var repassword=form["repassword"].value;
var fn_err=document.getElementById("fn_err");
var ln_err=document.getElementById("ln_err");
var un_err=document.getElementById("un_err");
var pass_err=document.getElementById("pw_err");
var repass_err=document.getElementById("rpw_err");
if(fname==""){
fn_err.innerHTML="Firstname is empty!";
}else{
fn_err.innerHTML="";
}
if(lname==""){
ln_err.innerHTML="Lastname is empty!";
}else{
ln_err.innerHTML="";
}
if(username==""){
un_err.innerHTML="Username is empty!";
}else{
un_err.innerHTML="";
}
if(password==""){
pass_err.innerHTML="Password is empty!";
}else{
pass_err.innerHTML="";
}
if(repassword==""){
repass_err.innerHTML="Re-type Password is empty!";
}else{
repass_err.innerHTML="";
}
if (username.length < 6) {
  alert('Please enter a username that is at least 6 characters long');	
  return false;
}
if (password.length < 6) {
  alert('Please enter a password that is at least 6 characters long');	
  return false;
}
if (form.password.value != form.repassword.value) {
  alert('Your password and confirmation password did not much!');	
  return false;
}
if(fname=="" || lname=="" || username=="" || password=="" || repassword==""){
alert("Please fill all required fields!");
return false
}else{
return true;
}
}
</script>
</head>

<body>
 <center>
 <ul id="menu">
	<li><a href="#">Home</a></li>
	<li>
		<a href="#">Transaction</a>
		<ul>
			<li><a href="#">aaa</a></li>
			<li><a href="#">aaa</a></li>
			<li><a href="#">aaa</a></li>
			<li><a href="#">aaa</a></li>
		</ul>
	</li>
	<li><a href="#">Set-up</a></li>
	<li><a href="#">Print</a></li>
	<li><a href="#">Help</a></li>
</ul>
 </center>
 
  <center>
   <div class="headerContainer">
      <div class="headerLeft">
        <img src="../Images/header.png" />
      </div>
      <div class="headerRight">
        <div class="searchContainer">
         <img src="../Images/search.png" class="search" />
         <input type="text" size="29" class="search" placeholder="GOOGLE SEARCH..."/>
        </div>
      </div>
   </div>
  </center>
  
  <center>
   <div class="mainContainerUserReg">
     <div class="userRegTop">
      <div class="userRegHeaderIcon">
       <img src="../Images/Users.png" class="userReg" />
      </div>
      <div class="userRegHeaderText">
       <p class="userReg">USER'S REGISTRATION</p>
      </div>
     </div>
     
     <div class="userRegLeft">
     <form name="userReg" id="userReg" method="post" action="" onsubmit="javascript:return validateTextBox();">
            <div class="Label">FIRSTNAME</div>
            <div id="fn_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:               20px; margin-left:5px;">
            </div>
            <div class="Text">
           <input class="Text" type="text" tabindex="1" name="firstname" value="<?php echo $firstname ?>" size="20" onKeyDown=             "CountLeft(this.form.firstname, this.form.fname,30);" onKeyUp="CountLeft(this.form.firstname,this.form.fname,30);"/>
            <input readonly type="text" name="fname" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">   
            </div>
            <div class="Label">LASTNAME</div><div id="ln_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" tabindex="2" type="text" value="<?php echo $lastname ?>" name="lastname" size="20" onKeyDown=             "CountLeft(this.form.lastname, this.form.lname,30);" onKeyUp="CountLeft(this.form.lastname,this.form.lname,30);"/>
           <input readonly type="text" name="lname" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">   
            </div>
            <div class="Label">USERNAME</div> 
            <div id="un_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px;">
            </div>
            <div class="Text"><input class="Text" type="text" tabindex="3" value="<?php echo $username ?>" name="username" size="20"  onKeyDown=             "CountLeft(this.form.username, this.form.uname,30);" onKeyUp="CountLeft(this.form.username,this.form.uname,30);"/> <input readonly type="text" name="uname" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">   
            </div>       
            <div class="Label">PASSWORD</div>
            <div id="pw_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" type="password" tabindex="4" value="<?php echo $password ?>" name="password" size="20" onKeyDown=             "CountLeft(this.form.password, this.form.pword,30);" onKeyUp="CountLeft(this.form.password,this.form.pword,30);"/><input readonly type="text" name="pword" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">
            </div>
            
            <div class="Label">RE-TYPE PASSWORD</div>
            <div id="rpw_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" type="password" tabindex="4" value="<?php echo $password ?>" name="repassword" size="20" onKeyDown=             "CountLeft(this.form.repassword, this.form.repword,30);" onKeyUp="CountLeft(this.form.repassword,this.form.repword,30);"/><input readonly type="text" name="repword" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">
            </div>
            
            <div class="Label">TYPE</div>
          <div class="Text">
          <select id="userType" name="type">
            <option value="<?php echo $type ?>">ADMIN</option>
            <option value="<?php echo $type ?>">USER</option>
          </select>
          </div>
          <div class="loginButton"><input  class="button" type="submit" name="submit" value="Register" /></div>        
          </form>
     </div>
      <div class="userRegRight">
       <div class="viewuser">
      <table>
			<?php
			include('../connection.php');
			//include("session.php");
			
			$result=mysql_query("SELECT * FROM tbluser");
			
			$color = "1";
			echo"<form method='post' name='form' id='form' action='delmultipleuser.php' onsubmit='return confirmdelete();'>";
			echo"<tr class='userReg'>
			       <th width='50' align='center'><input  id='delete' type='submit' name='delete' value='x'/></th>
			       <th width='70'>Firstname</th>
   			       <th width='70'>Lastname</th>
				   <th width='90'>Username</th>
  				   <th width='170'>Password</th>
				   <th width='170'>Type</th>
				   <th width='70'><center>Edit</certer></th>
				   <th width='70'><center>Delete</center></th>
			    </tr>";
			
			while($test = mysql_fetch_array($result))
			{
				if($color==1)
				 
				 {
				
					$id = $test['id'];	
					echo "<tr class='View1'>";	
					echo"<td  align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo"<td>" .$test['firstname']."</td>";
					echo"<td>". $test['lastname']. "</td>";
					echo"<td>". $test['username']. "</td>";
					echo"<td>". $test['password']. "</td>";	
					echo"<td>". $test['type']. "</td>";	
					echo"<td> <a href ='editUserReg.php?id=$id'><center><img class='editdelete' src='../Images/edit.png' /></center></a></td>";
					echo"<td width='70'><a href ='deluser.php?id=$id'><center><img class='editdelete'  src='../Images/delete.png' onclick='return confirmdelete();'/></center></a></td>";					
					echo "</tr>";
					
					$color = "2";
				 }
				 
				 else
				 
				 {
					 $id = $test['id'];	
					echo "<tr class='View2'>";	
					echo"<td width='50' align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo"<td width='90'>" .$test['firstname']."</td>";
					echo"<td width='90'>". $test['lastname']. "</td>";
					echo"<td width='90'>". $test['username']. "</td>";
					echo"<td width='170'>". $test['password']. "</td>";	
					echo"<td width='170'>". $test['type']. "</td>";	
					echo"<td width='70'> <a href ='editUserReg.php?id=$id'><center><img class='editdelete' src='../Images/edit.png'/></center></a>";
					echo"<td width='70'> <a href ='deluser.php?id=$id'><center><img class='editdelete' src='../Images/delete.png' onclick='return confirmdelete();'/></center></a>";					
					echo "</tr>";
					
					$color = "1";
				 }
				 
			}
			echo"</form>";
			mysql_close($conn);
			?>
</table>
   </div>
     </div>
   </div>
   
   <div class="footerContainer">
     <div class="footerMain">
       <div class="footerLeft">
        <p class="footer">
         Jameel A. Basher<br />
         Master of Science in Information Technology<br /><br />
         Online Inventory System<br />
         All Rights Reserved. &copy; Copyright 2012.<br /><br />
         <a href="" class="footerLink">HOME</a>&nbsp;|&nbsp;<a href="" class="footerLink">HOME</a>         &nbsp;|&nbsp;<a href="" class="footerLink">HOME</a>&nbsp;|&nbsp;<a href="" class="footerLink">HOME</a>   
        </p>
       </div>
       
       <div class="footerRight">
       
       </div>
     </div>
   </div>
  </center>
</body>
</html>