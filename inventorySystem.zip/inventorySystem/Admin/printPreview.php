<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Print Preview</title>
<link rel="stylesheet" type="text/css" href="print.css" />
<script type="text/javascript" src="print.js"></script> 
<style type="text/css">
table
 {
  width:780px;
  border:0px solid #666666;
 }
 
td
 {
 font-family:Geneva, Arial, Helvetica, sans-serif;
 font-size:13px;
 text-transform:uppercase;
 border:1px solid #00CC33;
 }

thead
 {
  font-weight:bold;
 }
 
div.head
 {
  width:780px;
  height:150px;
  background-color:#00CC33;
  margin-bottom:20px;
 }
</style>
</head>
<body>
<center>
<div class="head">
 <form action="filter.php" method="post">
From: <input name="from" type="text" class="tcal"/>
To: <input name="to" type="text" class="tcal"/>
<input name="" type="submit" value="Print" />
</form>
</div>
<table>
			<?php
			include('../connection.php');
			//include("session.php");
			
			$result=mysql_query("SELECT * FROM tblsupply ORDER BY description");

			echo"<thead>";
			echo"<tr>
			       <td width='220'>Description</th>
   			       <td width='90'  align='center'>Unit</th>
				   <td width='70'  align='center'>Date Purchased</th>
				   <td width='50'  align='center'>Qty</th>
  				   <td width='80'  align='center'>Unit Cost</th>
			    </tr>";
			echo"</thead>";
			
			while($test = mysql_fetch_array($result))
			{
				
				
					$id = $test['id'];	
					
					echo "<tr>";	
					echo"<td >" .$test['description']."</td>";
					echo"<td  align='center'>". $test['unit']. "</td>";
					echo"<td  align='center'>". $test['date']. "</td>";
					echo"<td  align='center'>". $test['quantity']. "</td>";	
					echo"<td  align='center'>". $test['unitcost']. "</td>";					
					echo "</tr>";
				
			}		
				
			mysql_close($conn);
			?>
</table>
</center>
</body>
</html>
