
<center>
<table border="0" height="500" width="950">
<tr>
<td align="center">
<?php

 echo '<meta http-equiv="refresh" content="2;url=index.php">';
 echo'<span><font size="5" color="#337033">LOADING!!!</font><br><img width="60" height="60" src="../../Images/ajax-loader.gif"></span>';


// Jump to login page
//header('Location: index.php');

?>
</td>
</tr>
</table>
</center>
