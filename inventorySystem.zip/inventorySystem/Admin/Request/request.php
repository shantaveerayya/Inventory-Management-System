<?php

define('INCLUDE_CHECK',1);
include('connection.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<title>Request Supply</title>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script src="../../filter/app.js" type="text/javascript" charset="utf-8"></script>
<script src="../../filter/application.js" type="text/javascript" charset="utf-8"></script>

<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="simpletip/jquery.simpletip-1.3.1.pack.js"></script>
<script type="text/javascript" src="script.js"></script>


<link rel="stylesheet" type="text/css" href="../../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../../CSS/general.css" />
<link rel="stylesheet" type="text/css" href="../../CSS/modalWindow.css" />


</head>

<body>

<center>
 <ul id="menu">
	<li><a href="../../Admin/home.php">Home</a></li>
	<li> <a href="#">Transaction</a> 
      <ul>
        <li><a href="../../Admin/supply.php">STOCK</a></li>
        <li><a href="../../Admin/Request/request.php">REQUEST ITEMS</a></li>
        <li><a href="../reqSupply.php">REQUESTED ITEMS</a></li>
        <li><a href="../reqSupply.php">ORDER PLACED</a></li>
	  </ul>
    </li>
	<li> <a href="#">Set-up</a> 
      <ul>
        <li><a href="../../Admin/addDiv.php">DIVISION</a></li>
        <li><a href="../../Admin/employee.php">EMPLOYEE</a></li>
        <li><a href="../../Admin/userReg.php">USER MGNT</a></li>
      </ul>
    </li>
	<li> <a href="#">TOOLS</a> 
      <ul>
        <li><a href="#">USER'S LOG</a></li>
        <li><a href="../../Admin/databasebackup/backupDB.php">BACK-UP DATABASE</a></li>
      </ul>
    </li>
	<li><a href="#">Print</a></li>
	<li><a href="#">Help</a></li>
     <div style="float:right; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF; margin-right:5px">
	 
   <SCRIPT LANGUAGE="Javascript">
<!-- 

// Array of day names
var dayNames = new Array("Sunday","Monday","Tuesday","Wednesday",
				"Thursday","Friday","Saturday");

// Array of month Names
var monthNames = new Array(
"January","February","March","April","May","June","July",
"August","September","October","November","December");

var now = new Date();
document.write(dayNames[now.getDay()] + ", " + 
monthNames[now.getMonth()] + " " + 
now.getDate() + ", " + now.getFullYear());

// -->
</SCRIPT>
     <div id="txt"></div>
    </div>
</ul>
 </center>
 
  <center>
   <?php include("../../header1.php"); ?>
  </center>

 
 
<div id="main-container"> 
   <div class="head">
    <div class="searchContainer1">
         <img src="../../Images/google_custom_search.png" class="search1" />
         <input type="text" size="45" class="search1" placeholder="SEARCH..." name="filter" value="" id="filter"/>
		 <p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#00CC33;"></p>
         </div>
   </div>
   		<div class="content drag-desired">
           <table>
                <?php
               
				$result = mysql_query("SELECT * FROM tblsupply");
				while($row=mysql_fetch_assoc($result))
				{
				    echo'<tr>';
					echo'<td>';
					echo '<div class="con">';
					echo '<div class="product"><img src="../../../inventorySystem/Admin/Image/'.$row['img'].'" alt="'.htmlspecialchars($row['description']).'" width="70" height="70" class="pngfix" />';
					echo '</div>';
					echo '<div class="d">' . 'Desc:&nbsp' . $row['description'] . '<br>' . 'Unit:&nbsp;'.  $row['unit'] . '<br>' . 'Unit Cost:&nbsp;' .  $row['unitcost'] . '<br>' . 'Qty:&nbsp;' .  $row['quantity'] .'</div>';
					echo'</div>';
					echo'<td>';
					echo'<tr>';
				}

				?>
                </table>
        
       	        <div class="clear"></div>
               
    </div>




 
    		<div class="content drop-here">
            	
  <div id="cart-icon"> 
    <p style="margin:15px auto auto 5px; color:#FFFFFF;">Drop here your requested 
      supplies!!!</p>
  </div>
				<div class="dh">
				<form name="checkoutForm" method="post" action="execReq.php">
				
				  <div class="t1">Name</div>
				  <div class="t">Date</div>
				    <div class="t">Division</div>
				
				   <div class="t1"><input class="modText" type="text" tabindex="1" name="name" value="" size="17" /></div>
				   <div class="t"><input type="text" id="datepicker" class="modText" size="8" name="date"/></div>				
				    <div class="t"><select name="type" id="userType">
         <?php
		   include("connection.php");
           $query_disp="SELECT * FROM division order by division asc";
           $result_disp = mysql_query($query_disp);
            while($query_data = mysql_fetch_array($result_disp))
              {
          ?>
<option value="<?php echo $query_data['division']; ?>"><?php echo $query_data['division']; ?></option>
<?php } ?>
      </select></div>
				                
                <div id="item-list">
                </div>
                
				             
                <div class="clear"></div>

				<div id="total"></div>

       	        <div class="clear"></div>
                
                <a onclick="document.forms.checkoutForm.submit(); return false;" class="button">Request</a>
                 
          </div>
</div></form> 
</div>
<center>
   <?php include("../../footer.php"); ?>  
  </center>
  
</body>
</html>
