<?php

define('INCLUDE_CHECK',1);
require "../connection.php";

if(!$_POST['img']) die("There is no such product!");

$img=mysql_real_escape_string(end(explode('/',$_POST['img'])));
$row=mysql_fetch_assoc(mysql_query("SELECT * FROM tblsupply WHERE img='".$img."'"));

echo '{status:1,id:'.$row['id'].',price:'.$row['unitcost'].',txt:\'\
\
<table cellpading="2" id="table_'.$row['id'].'">\
 <thead>\
  <tr>\
   <td>Description</td>\
   <td>Unit Cost</td>\
   <td>Unit</td>\
   <td>Qty</td>\
    <td>Rem. Bal.</td>\
  </tr>\
 </thead>\
  <tr>\
  <td width="60%" style="display:none;"><input type="text" name="id[]" value="'.$row['id'].'" style="width: 28px; border-width: 0px;"></td>\
    <td width="225"><input size="30" type="text" name="desc[]" value="'.$row['description'].'" ></td>\
	<td width="30"><input type="text" name="uc[]" value="P'.$row['unitcost'].'"  size="2"></td>\
    <td width="40"><input type="text" name="unit[]"  value="'.$row['unit'].'" size="3"></td>\
    <td width="30"><input type="text" name="qty[]" size="3" onChange="return Total1(this)" id="'.$row['id'].'_cnt" id="'.$row['id'].'_cnt" onchange="change('.$row['id'].');"></td>\
	<td width="30"><input type="text" id="num2" onChange="return Total1(this)" name="balance[]" value="'.$row['quantity'].'" size="3"></td>\
	<td width="20"><a href="#" onclick="remove('.$row['id'].');return false;" class="remove"><img class="editdelete" src="../../Images/cross.png" alt="Delete"></a></td>\
  </tr>\
</table>\'}';
?>
 