<?php

define('INCLUDE_CHECK',1);
require "../connection.php";

if(!$_POST['img']) die("There is no such product!");

$img=mysql_real_escape_string(end(explode('/',$_POST['img'])));

$row=mysql_fetch_assoc(mysql_query("SELECT * FROM tblsupply WHERE img='".$img."'"));

if(!$row) die("There is no such product!");

echo "Description: ";
echo '<strong>'.$row['description'].'</strong>

<br>

Unit Cost:<strong> '.$row['unitcost'].'</strong><br>
Remaining Balance:<strong> '.$row['quantity'].'</strong>
<small>Drag it to your shopping cart to purchase it</small>';
?>
