<?php
include ("connection.php");

$name= $_REQUEST['name'];
$date = $_REQUEST['date'];
$type = $_REQUEST['type'];

$reqid = $_REQUEST['id'];
$desc = $_REQUEST['desc'];
$uc = $_REQUEST['uc'];
$unit = $_REQUEST['unit'];
$qty = $_REQUEST['qty'];
$bal = $_REQUEST['balance'];

$N = count($reqid);
				$ip_sqlq=mysql_query("select * from tblrequest");
					$countq=mysql_num_rows($ip_sqlq);
					if($countq>=0)
					{
						for($i=0; $i < $N; $i++)
						{
						
						$a= $qty[$i];
					    $b= $bal[$i];
					    $c= $b - $a;
						$d= $reqid[$i]; 
					
						
$insert = mysql_query("INSERT INTO tblrequest (id, name, date, division, description, unitcost, unit, qty) VALUES ('', '$name', '$date', '$type', '$desc[$i]', '$uc[$i]', '$unit[$i]', '$qty[$i]')");

$update = mysql_query("UPDATE tblsupply SET quantity = '$c' WHERE id='$d'");
if(!$update){

die("There's little problem: ".mysql_error());

}

if(!$insert){

die("There's little problem: ".mysql_error());

}
}}

include("loading.php");
echo '<meta http-equiv="refresh" content="1;url=request.php">';

?>