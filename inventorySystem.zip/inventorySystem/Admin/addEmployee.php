<script type="text/javascript">
function validateForm()
{
var a=document.forms["addEmployee"]["firstname"].value;
if (a==null || a=="")
  {
  alert("Firstname is empty!");
  return false;
  }
var b=document.forms["addEmployee"]["lastname"].value;
if (b==null || b=="")
  {
  alert("Lastname is empty!");
  return false;
  }
 var c=document.forms["addEmployee"]["mi"].value;
if (c==null || c=="")
  {
  alert("M/F is empty!");
  return false;
  }
var d=document.forms["addEmployee"]["address"].value;
if (d==null || d=="")
  {
  alert("Address is empty!");
  return false;
  }
 var e=document.forms["addEmployee"]["userType"].value;
if (e==null || e=="")
  {
  alert("Division is empty!");
  return false;
  }
/*if (c.which!=8 && c.which!=0 && (c.which<48 || c.which>57))
  {
  alert("The input U enter in Quantity field is not valid, only numbers are accepted (ex. 1, 2, 3, 4.......)");
  return false;
  }
if (b.which!=8 && b.which!=0 && (b.which<48 || b.which>57))
  {
  alert("The input U enter in Quantity field is not valid, only numbers are accepted (ex. 1, 2, 3, 4.......)");
  return false;
  }*/
}
</script>
<link rel="stylesheet" type="text/css" href="../CSS/general.css"/>
<link rel="stylesheet" type="text/css" href="../CSS/modalWindow.css"/>

<div class="modCon">
 <center>
   <div class="modHeader">
    <h3 class="modalHeader">
    ADD or EDIT EMPLOYEE INFORMATON
    </h3>
   </div>
 <form action="execAddemp.php" method="post" enctype="multipart/form-data" name="addEmployee" onsubmit="return validateForm()">  
   <div class="modContent">
    <div class="Row">
	  <div class="box"><p class="modLabel">FIRSTNAME</p></div>
	  <div class="box"><p class="modLabel">LASTNAME</p></div>
	  <div class="box"><p class="modLabel">M/F</p></div>
	  
	  <div class="box1"><input class="modText" type="text" tabindex="1" name="firstname" value="" size="13" /></div>
	  <div class="box1"><input class="modText" type="text" tabindex="2" name="lastname" value="" size="13" /></div>
	  <div class="box1"><input class="modText" type="text" tabindex="3" name="mi" value="" size="13" /></div>
	</div>
	
	<div class="Row">
	  <div class="box"><p class="modLabel">DESIGNATION</p></div>
	  <div class="box"><p class="modLabel"></p></div>
	  <div class="box"><p class="modLabel"></p></div>
	  
	  <div class="box1"><input class="modText" type="text" tabindex="1" name="address" value="" size="30" /></div>
	  <div class="box1"></div>
	  <div class="box1"><select name="userType" id="moduserType">
         <?php
		   include("../connection.php");
           $query_disp="SELECT * FROM division order by division asc";
           $result_disp = mysql_query($query_disp);
            while($query_data = mysql_fetch_array($result_disp))
              {
          ?>
<option value="<?php echo $query_data['division']; ?>"><?php echo $query_data['division']; ?></option>
<?php } ?>
      </select></div>	  
	</div>
	
	<div class="Row">
	  <input type="submit" name="submit" value="save" class="button"/>
	</div>
	
   </div>
  </form>
 </center>
</div>