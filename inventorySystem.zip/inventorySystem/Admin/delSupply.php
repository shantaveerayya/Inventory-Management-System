<?php
  include("../connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	$del = mysql_query("DELETE FROM tblsupply WHERE id = '$id'")
	or die(mysql_error()); 

	header("Location: supply.php");
?>