<?php
include ("../connection.php");


$supplier = $_REQUEST['supplier'];
$item_name = $_REQUEST['item_name'];
$unit = $_REQUEST['unit'];
$date = $_REQUEST['date1'];
$qty = $_REQUEST['qty'];
$unitcost = $_REQUEST['unitcost'];

$check = mysql_query("SELECT * FROM tblorders WHERE item_name = '$item_name'");

$do_check = mysql_num_rows($check);

//Now display errors


if($do_check > 0){

die($item_name . " " .  "is already in use!<br>");

}


$insert = mysql_query("INSERT INTO tblorders (id, supplier, item_name, unit, date, quantity, unitcost ) VALUES ('', '$supplier', '$item_name', '$unit', '$date', '$qty', '$unitcost')");

if(!$insert){

die("There's little problem: ".mysql_error());

}

include("loading.php");
echo '<meta http-equiv="refresh" content="1;url=supply.php">';

?>