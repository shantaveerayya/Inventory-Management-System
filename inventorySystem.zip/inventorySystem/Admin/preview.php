<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Print Preview</title>
<link rel="stylesheet" type="text/css" href="print.css" />
<script type="text/javascript" src="print.js"></script> 

<script src="../filter/app.js" type="text/javascript" charset="utf-8"></script>
<script src="../filter/application.js" type="text/javascript" charset="utf-8"></script>
<!--box -->
<script language="javascript" src="../lib/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="../facebox/facebox.css" />

<script language="javascript" src="../facebox/facebox.js"></script>

<script language="javascript">
jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'facebox/loading.gif',
    
      })
    })
</script>
<!--endbox -->
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
<link rel="stylesheet" type="text/css" href="../CSS/modalWindow.css" />

<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script>
function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>
</head>

<body onload="startTime()">
 <center>
  <?php include("../menu.php"); ?>
 </center>
 
  <center>
   <?php include("../header.php"); ?>
  </center>
  
   <center>
     <div class="print">
	   <div class="preview">
	    <div class="previewHead">
	      <p class="previewHead">PRINT PREVIEW | PRINTING OPTION</p>
	    </div>
		<div class="previewCon">
		 <form action="filter.php" method="post">
1. By Date - From: <input name="from" type="text" class="tcal"/>
To: <input name="to" type="text" class="tcal"/>
<input name="" type="submit" value="Print" />
</form>
		</div>
		<div class="previewCon">
		 <form action="description.php" method="post">
2. By Description &nbsp;&nbsp;<input name="desc" type="text"/>
<input name="" type="submit" value="Print" />
</form>
		</div>
		<div class="previewCon">
		 3. <a href="reorderPoint.php">Within Reorder Point</a>
		</div>
		<div class="previewCon">
		 4. <a href="allSupplies.php">All Suplies</a>
		</div>
	   </div>
	   
	   <div class="empCon">
	   
       <div class="viewuser">
      <table>
			<?php
			include('../connection.php');
			//include("session.php");
			
			$result=mysql_query("SELECT * FROM tblsupply ORDER BY description");
			
			$color = "1";
			echo"<form method='post' name='form' id='form' action='delmultipleEmp.php' onsubmit='return confirmdelete();'>";
			echo"
			   <thead>
			   <tr class='empHead'>
			       <td width='380'>Description</th>
   			       <td width='170'  align='center'>Unit</th>
				   <td width='120'  align='center'>Date Purchased</th>
				   <td width='100'  align='center'>Qty</th>
  				   <td width='110'  align='center'>Unit Cost</th>
			    </tr>
				 </thead>";
			
			while($test = mysql_fetch_array($result))
			{
				if($color==1)
				 
				 {
				
					$id = $test['id'];	
					echo "<tbody>";
					echo "<tr class='View1emp'>";	
					echo"<td >" .$test['description']."</td>";
					echo"<td  align='center'>". $test['unit']. "</td>";
					echo"<td  align='center'>". $test['date']. "</td>";
					echo"<td  align='center'>". $test['quantity']. "</td>";	
					echo"<td  align='center'>". $test['unitcost']. "</td>";						
					echo "</tr>";
					echo "</tbody>";
					
					$color = "2";
				 }
				 
				 else
				 
				 {
					 $id = $test['id'];	
					 echo "</tbody>";
					echo "<tr class='View2emp'>";	
					echo"<td >" .$test['description']."</td>";
					echo"<td  align='center'>". $test['unit']. "</td>";
					echo"<td  align='center'>". $test['date']. "</td>";
					echo"<td  align='center'>". $test['quantity']. "</td>";	
					echo"<td  align='center'>". $test['unitcost']. "</td>";			
					echo "</tr>";
					echo "</tbody>";
					
					$color = "1";
				 }
				 
			}
			
			echo"</form>";
			mysql_close($conn);
			?>
</table>
   </div>
	   </div>
	 </div>
   </center> 
   
  
  <center>
   <?php include("../footer.php"); ?>  
  </center>
</body>
</html>