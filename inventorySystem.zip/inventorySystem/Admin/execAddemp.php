<?php
include ("../connection.php");

$firstname = $_REQUEST['firstname'];
$lastname = $_REQUEST['lastname'];
$mi = $_REQUEST['mi'];
$address = $_REQUEST['address'];
$div = $_REQUEST['userType'];

$check = mysql_query("SELECT * FROM employee WHERE firstname='$firstname' AND lastname='$lastname'");

$do_check = mysql_num_rows($check);

//Now display errors


if($do_check > 0){

die($firstname . " " . $lastname . " " . "is already in use!<br>");

}


$insert = mysql_query("INSERT INTO employee (id, firstname, lastname, mi, address, division) VALUES ('', '$firstname', '$lastname', '$mi', '$address', '$div')");

if(!$insert){

die("There's little problem: ".mysql_error());

}

include("loading.php");
echo '<meta http-equiv="refresh" content="1;url=employee.php">';
//echo "<a href='adddivisions.php'>back</a>";
?>


