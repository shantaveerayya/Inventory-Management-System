<?php
  include("../connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	$del = mysql_query("DELETE FROM tblorders WHERE id = '$id'")
	or die(mysql_error()); 

	header("Location: orderPlaced.php");
?>