<?php
  include("../connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	$del = mysql_query("DELETE FROM employee WHERE id = '$id'")
	or die(mysql_error()); 

	header("Location: employee.php");
?>