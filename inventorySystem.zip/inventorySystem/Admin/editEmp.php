<?php
include('../connection.php');
$id =$_REQUEST['id'];

$result = mysql_query("SELECT * FROM employee WHERE id  = '$id'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$firstname=$test['firstname'] ;
				$lastname= $test['lastname'] ;					
				$mi=$test['mi'] ;
				$address=$test['address'] ;
				$type = $test['division'];

if(isset($_POST['submit']))
{	

	$firstname_save = $_POST['firstname'];
	$lastname_save = $_POST['lastname'];
	$mi_save = $_POST['mi'];
	$address_save = $_POST['address'];
	$type_save = $_POST['userType'];

	mysql_query("UPDATE employee SET firstname ='$firstname_save', lastname ='$lastname_save',
		 mi ='$mi_save', address ='$address_save', division ='$type_save' WHERE id = '$id'")
				or die(mysql_error()); 
				
	echo"Save!";
	
	header("Location: employee.php");			
}
mysql_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User Registration</title>
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script language="javascript">
function CountLeft(field, count, max) {
if (field.value.length > max)
field.value = field.value.substring(0, max);
else
count.value = max - field.value.length;
}
</script>
<script type="text/javascript" language="javascript">

function validateTextBox(){
var form=document.getElementById("userReg");
var fname=form["firstname"].value;
var lname=form["lastname"].value;
var username=form["username"].value;
var password=form["password"].value;
var repassword=form["repassword"].value;
var fn_err=document.getElementById("fn_err");
var ln_err=document.getElementById("ln_err");
var un_err=document.getElementById("un_err");
var pass_err=document.getElementById("pw_err");
var repass_err=document.getElementById("rpw_err");
if(fname==""){
fn_err.innerHTML="Firstname is empty!";
}else{
fn_err.innerHTML="";
}
if(lname==""){
ln_err.innerHTML="Lastname is empty!";
}else{
ln_err.innerHTML="";
}
if(username==""){
un_err.innerHTML="Username is empty!";
}else{
un_err.innerHTML="";
}
if(password==""){
pass_err.innerHTML="Password is empty!";
}else{
pass_err.innerHTML="";
}
if(repassword==""){
repass_err.innerHTML="Re-type Password is empty!";
}else{
repass_err.innerHTML="";
}
if (username.length < 6) {
  alert('Please enter a username that is at least 6 characters long');	
  return false;
}
if (password.length < 6) {
  alert('Please enter a password that is at least 6 characters long');	
  return false;
}
if (form.password.value != form.repassword.value) {
  alert('Your password and confirmation password did not much!');	
  return false;
}
if(fname=="" || lname=="" || username=="" || password=="" || repassword==""){
alert("Please fill all required fields!");
return false
}else{
return true;
}
}
</script>
<script>
function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>
</head>

<body onload="startTime()">
 <center>
  <?php include("../menu.php"); ?>
 </center>
 
  <center>
   <?php include("../header.php"); ?>
  </center>
  
  <center>
   <div class="mainContainerUserReg">
     <div class="userRegTop">
      <div class="userRegHeaderIcon">
       <img src="../Images/group_edit.png" class="userReg" />
      </div>
      <div class="userRegHeaderText">
       <p class="userReg">UPDATE EMPLOYEE</p>
      </div>
     </div>
     
     <div class="userRegLeft">
     <form name="userReg" id="userReg" method="post" action="" onsubmit="javascript:return validateTextBox();">
            <div class="Label">FIRSTNAME</div>
            <div id="fn_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px;">
            </div>
            <div class="Text">
           <input class="Text" type="text" tabindex="1" name="firstname" size="19" value="<?php echo $firstname ?>"/>
            </div>
            <div class="Label">LASTNAME</div><div id="ln_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" tabindex="2" type="text" name="lastname" size="19" value="<?php echo $lastname ?>"/> 
            </div>
            <div class="Label">M/F</div> 
            <div id="un_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px;">
            </div>
            <div class="Text"><input class="Text" type="text" tabindex="3" name="mi" size="19"  value="<?php echo $mi ?>"/> 
            </div>       
            <div class="Label">DESIGNATION</div>
            <div id="pw_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:20px; margin-left:5px">
            </div>
            <div class="Text"><input class="Text" type="text" tabindex="4" name="address" size="19" value="<?php echo $address ?>"/>
            </div>
            
            <div class="Label">TYPE</div>
          <div class="Text">
           <label>
        <select name="userType" id="userType" value="<?php echo $type ?>">
         <?php
		   include("../connection.php");
           $query_disp="SELECT * FROM division order by division asc";
           $result_disp = mysql_query($query_disp);
            while($query_data = mysql_fetch_array($result_disp))
              {
          ?>
<option value="<?php echo $query_data['division']; ?>"><?php echo $query_data['division']; ?></option>
<?php } ?>
      </select>

      </label>
          </div>
          <div class="loginButton"><input  class="button" type="submit" name="submit" value="Update" /></div>        
          </form>
     </div>
      
     
   </div>
  </center>
  
  <center>
   <?php include("../footer.php"); ?>  
  </center>
</body>
</html>