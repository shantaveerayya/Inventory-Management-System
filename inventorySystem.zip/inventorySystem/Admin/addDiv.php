<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Division</title>
<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />
<script type="text/javascript"> 
function confirmdelete()
{ 
 return confirm("Are you sure you want to delete?");  
} 
</script> 
<script type="text/javascript" language="javascript">
function validateTextBox(){
var form=document.getElementById("divform");
var divname=form["div"].value;
var div_err=document.getElementById("div_err");

if(divname==""){
div_err.innerHTML="Textbox is empty!";
}else{
fn_err.innerHTML="";
}
if(divname==""){
alert("Please fill all required fields!");
return false
}else{
return true;
}
}
</script>
<script language="javascript">
function CountLeft(field, count, max) {
if (field.value.length > max)
field.value = field.value.substring(0, max);
else
count.value = max - field.value.length;
}
</script>
</head>

<body>
 <center>
  <?php include("../menu.php"); ?>
 </center>
 
  <center>
   <?php include("../header.php"); ?>
  </center>
  
  <center>
   <div class="mainContainerDiv">
     <div class="userRegTop">
      <div class="divHeaderIcon">
       <img src="../Images/division.png" class="userReg" />
      </div>
      <div class="divHeaderText">
       <p class="div">DIVISION</p>
      </div>
     </div>
     
     <div class="userRegLeft">
<form name="divform" id="divform" method="post" action="execDiv.php"  onsubmit="javascript:return validateTextBox();">
            <div class="Label">DIVISION</div>
            <div id="div_err" style="color:#FF0000; font-style:italic; text-align:left; line-height:               20px; margin-left:5px;">
            </div>
            <div class="Text">
           <input class="Text" type="text" tabindex="1" name="div" value="" size="20" onKeyDown=             "CountLeft(this.form.div, this.form.type,30);" onKeyUp="CountLeft(this.form.div,this.form.type,30);"/>
            <input readonly type="text" name="type" size="1" maxlength="3" value="30" disabled="disabled" id="textCounter">   
            </div>
          
          <div class="loginButton"><input  class="button" type="submit" name="submit" value="Add" /></div>        
          </form>
     </div>
      <div class="divRight">
       <div class="viewDiv">
      <table align="left">
			<?php
			include('../connection.php');
			//include("session.php");
			
			$result=mysql_query("SELECT * FROM division");
			
			$color = "1";
			echo"<form method='post' name='form' id='form' action='delmultipleDiv.php' onsubmit='return confirmdelete();'>";
			echo"<tr class='userReg'>
			       <th width='50' align='center'><input  id='delete' type='submit' name='delete' value='x'/></th>
			       <th width='500'>Division</th>
				   <th width='50'><center>Edit</certer></th>
				   <th width='50'><center>Delete</center></th>
			    </tr>";
			
			while($test = mysql_fetch_array($result))
			{
				if($color==1)
				 
				 {
				
					$id = $test['id'];	
					echo "<tr class='View1'>";	
					echo"<td width='50'  align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo"<td width='150'>" .$test['division']."</td>";
					echo"<td width='50'> <a href ='editDiv.php?id=$id'><center><img class='editdelete' src='../Images/edit.png' /></center></a></td>";
					echo"<td width='50'><a href ='delDiv.php?id=$id'><center><img class='editdelete'  src='../Images/delete.png' onclick='return confirmdelete();'/></center></a></td>";					
					echo "</tr>";
					
					$color = "2";
				 }
				 
				 else
				 
				 {
					 $id = $test['id'];	
					echo "<tr class='View2'>";	
					echo"<td width='50' align='center'> <input type='checkbox' name='checkbox[]' id='checkbox[]'  value=$id /> </td>";
					echo"<td width='150'>" .$test['division']."</td>";
					echo"<td width='50'> <a href ='editDiv.php?id=$id'><center><img class='editdelete' src='../Images/edit.png'/></center></a>";
					echo"<td width='50'> <a href ='delDiv.php?id=$id'><center><img class='editdelete' src='../Images/delete.png' onclick='return confirmdelete();'/></center></a>";					
					echo "</tr>";
					
					$color = "1";
				 }
				 
			}
			echo"</form>";
			mysql_close($conn);
			?>
</table>
   </div>
     </div>
     
   </div>
  </center>
  
  <center>
   <?php include("../footer.php"); ?>  
  </center>
</body>
</html>