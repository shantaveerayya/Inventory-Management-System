<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Inventory System</title>	
<link rel="stylesheet" type="text/css" href="CSS/menuIndex.css" />
<link rel="stylesheet" type="text/css" href="CSS/general.css" />
<!-- stylesheets -->
  	<link rel="stylesheet" href="Sliding_login_panel_jquery/css/slide.css" type="text/css" media="screen" />
	
  	<!-- PNG FIX for IE6 -->
  	<!-- http://24ways.org/2007/supersleight-transparent-png-in-ie6 -->
	<!--[if lte IE 6]>
		<script type="text/javascript" src="js/pngfix/supersleight-min.js"></script>
	<![endif]-->
	 
    <!-- jQuery - the core -->
	<script src="Sliding_login_panel_jquery/js/jquery-1.3.2.min.js" type="text/javascript"></script>
	<!-- Sliding effect -->
	<script src="Sliding_login_panel_jquery/js/slide.js" type="text/javascript"></script>

<script type="text/javascript" language="javascript">
function validateTextBox(){
var form=document.getElementById("loginform");
var username=form["username"].value;
var password=form["password"].value;
var un_err=document.getElementById("un_err");
var pw_err=document.getElementById("pw_err");
if(username==""){
un_err.innerHTML="Username is empty!";
}else{
un_err.innerHTML="";
}
if(password==""){
pw_err.innerHTML="Password is empty!";
}else{
pw_err.innerHTML="";
}
if(username=="" || password==""){
alert("Invalid username and password...");
return false
}else{
return true;
}
}
</script>
<script>
function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();
// add a zero in front of numbers<10
m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>

<link rel="stylesheet" href="slideShow/Styles/default/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="slideShow/Styles/nivo-slider.css" type="text/css" media="screen" />
	 <script type="text/javascript" src="slideShow/JScript/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="slideShow/JScript/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript"> $(window).load(function() {   $('#slider').nivoSlider(); }); </script>  
</head>

<body onload="startTime()">
<!-- Panel -->	
<div id="toppanel">
	<div id="panel">
		<div class="content clearfix">
			<div class="left">
				<h1 style="color:#00CC66">Online Inventory System</h1>
				<h2 style="color:#00CCFF">Feature:</h2>		
				 <ul style="list-style-image:url(Images/pin.png);color:#333333">
				  <li>Add, Edit, Delete, Search supply.</li>
				  <li>Add, Edit, Delete, Search supply.</li>
				  <li>Add, Edit, Delete, Search supply.</li>
				  <li>Add, Edit, Delete, Search supply.</li>
				 </ul>
			</div>
			<div class="left">
			<div class="usersLoginHeader">
           <p class="usersHeader">Sign-up for free...</p>
         </div>
				<p style="color:#333333">You may create your own account to access the Online Inventory System by 
				<a href="Admin/userRegmember.php" style="color:#0099FF; text-decoration:underline;">Clicking Here!!!</a></p>			
			</div>
			<div class="left">
			<img src="Images/Users.png" class="users" />&nbsp;<p class="usersHeader">USER'S LOG-IN</p><br /><br /><br />
				<!-- Login Form -->
				<form name="loginform" id="loginform" method="post" action="loginExec.php" onsubmit="javascript:return validateTextBox();">
          <div class="Label">USERNAME</div> <div id="un_err" style="color:#999999; font-size:13px; font-style:italic; text-align:left; line-height:20px; margin-left:1px;"></div>    
          <div class="Text"><input class="Text" type="text" name="username" size="20" style="text-transform:uppercase"/></div>  
          <div class="Label">PASSWORD</div><div id="pw_err" style="color:#999999; font-size:13px; font-style:italic; text-align:left; line-height:20px; margin-left:5px"></div>
          <div class="Text"><input class="Text" type="password" name="password" size="20" /></div>
          <div class="loginButton"><input class="button" type="submit" name="submit" value="LOG-IN" /></div>
         
          </form>
			</div>
		</div>
</div> <!-- /login -->	

	<!-- The tab on top -->	
	<div class="tab">
		<ul class="login">
			<li class="left">&nbsp;</li>
			<li>Hello Guest!</li>
			<li class="sep">|</li>
			<li id="toggle">
				<a id="open" class="open" href="#">Log In | Register</a>
				<a id="close" style="display: none;" class="close" href="#">Close Panel</a>			
			</li>
			<li class="right">&nbsp;</li>
		</ul> 
	</div> <!-- / top -->
	
</div> <!--panel -->

 
<!-- Header -->	
  <center>
   <div class="headerContainer1">
      <div class="headerLeft">
        <img src="Images/header.png" />
      </div>
      <div class="headerRight">
        <div class="searchContainer">
         <img src="Images/search.png" class="search" />
         <input type="text" size="29" class="search" placeholder="GOOGLE SEARCH..."/>
        </div>
      </div>
   </div>
  </center>
<!-- End Header -->	

<!-- Main -->	  
  <center>
   <div class="mainContainerIndex">
   <div class="menuIndex">
   <ul id="menuI">
	<li><a href="#">Home</a></li>
	<li><a href="#">About Us</a></li>
  </ul>
   </div>
    <div id="wrapper">
        <div class="slider-wrapper theme-default">
            <div class="ribbon"></div>
            <div id="slider" class="nivoSlider">
                <img src="slideShow/Images/4.jpg" alt="Mariculture Park" />
                <img src="slideShow/Images/2.jpg" alt="Payao" title=""/>
                <img src="slideShow/Images/3.jpg" alt="" title=""/>
				<img src="slideShow/Images/1.jpg" alt="" title=""/>
            </div>
        </div>
    </div>
	
	<div class="mvg">
	 <div class="m">
	   <div class="mvgHead">
	     <div class="mvgIcon">
		  <img src="Images/mvg.png" />
		 </div>
		 <div class="mvgTitle">
		  <h2 class="mvg">MISSION</h1>
		 </div>
		 <div class="mvgText">
		  <p class="mvg">
		   The Bureau of Fisheries and Aquatic Resources as a line bureau under the Department of Agriculture, shall:
		    <ul type="square" style="font-family:Arial, Helvetica, sans-serif; line-height:20px; font-size:12px; margin-left:-12px; color:#333333; text-align:justify;">
			 <li>Conserve,             protect and sustain the development of fishery and aquatic   resources             through sound management practices; </li>
			 <li>Alleviate poverty with the provision of supplementary   livelihood through             community-based enterprise development among fisherfolk; </li>
			 <li>Improve the productivity of aquaculture within ecological   limits through             sound management skills;</li>
			 <li>Optimally utilize offshore and deep sea resources;</li>
			 <li>Promote the upgrading of post-harvest technology management. </li>
			</ul>
		  </p>
		 </div>
	   </div>
	 </div>
	 
	 
	 <div class="v">
	   <div class="mvgHead">
	     <div class="mvgIcon">
		  <img src="Images/mvg.png" />
		 </div>
		 <div class="mvgTitle">
		  <h2 class="mvg">VISION</h1>
		 </div>
		 <div class="mvgText">
		  <p class="mvg">
		     A modernized fishery sector that is technologically advanced and globally competitive guided by the principles of social justice and equity, sound management practices with strong private community participation for the sustainable development of fishery resources instituted. 
		  </p>
		 </div>
	   </div>
	 </div>
	 </div>
	 
	</div>
   </div>
  </center>
<!-- End Main -->	  

<!-- footer -->	
  <center>  
   <?php include("footer.php"); ?>  
  </center>
<!-- End Footer -->	

</body>
</html>