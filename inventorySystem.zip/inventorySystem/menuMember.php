<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />

<ul id="menu">
	<li><a href="../index.php">Home</a></li>
	<li><a href="#">About Us</a></li>
     <div style="float:right; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF; margin-right:5px">
     <SCRIPT LANGUAGE="Javascript">
<!-- 

// Array of day names
var dayNames = new Array("Sunday","Monday","Tuesday","Wednesday",
				"Thursday","Friday","Saturday");

// Array of month Names
var monthNames = new Array(
"January","February","March","April","May","June","July",
"August","September","October","November","December");

var now = new Date();
document.write(dayNames[now.getDay()] + ", " + 
monthNames[now.getMonth()] + " " + 
now.getDate() + ", " + now.getFullYear());

// -->
</SCRIPT>
     <div id="txt"></div>
    </div>
</ul>