<?php

// Inialize session
session_start();

// Include database connection settings
include('connection.php');

$username = $_REQUEST['username'];
$password = $_REQUEST['password'];


//Retrieve username and password from database according to user's input
$login = mysql_query("SELECT * FROM tbluser
				WHERE ((`tbluser`.`username` = '$username') AND (`tbluser`.`password` = '$password')  AND (`tbluser`.`confirmation` = '1'))");

// Check username and password match
if (mysql_num_rows($login) == 1) 
 {
        // Set username session variable
		session_register('is');
		$_SESSION['is']['submit']    = TRUE;
        $_SESSION['username'] = $_POST['username'];
		$session = "1";
		
		$qry = mysql_query("SELECT * FROM session WHERE username = '$username'");
		
		$fetch = mysql_fetch_array($qry);
		$id = $fetch['session_id'];
				
		if($id > 1)
		 {
		$update = "UPDATE session SET session_id= '$id', username = '$username',  session_date = CURRENT_TIMESTAMP WHERE username = '$username'";
    	$add_session = mysql_query($update);
		 }
		else 
		 {
		$insert = "INSERT INTO session SET session_id= '', username = '$username',  session_date = CURRENT_TIMESTAMP";
    	$add_session = mysql_query($insert);
		 }
		 
		$query = mysql_query("SELECT * FROM tbluser WHERE username = '$username'");
		$get = mysql_fetch_array($query);
		$type = $get['type'];
		
		if($type == "Admin" or $type =="admin")
		{
        // Jump to secured page
        header('Location: Admin/home.php');
		}
		else
		{
   	    header('Location: Admin/Request/request.php');
		}
		
  }
  else 
  {
        // Jump to login page
        header('Location: index.php');
  }

?>
