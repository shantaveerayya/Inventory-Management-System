-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 14, 2013 at 04:51 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventorysystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE IF NOT EXISTS `division` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `division` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`id`, `division`) VALUES
(29, 'ADMINISTRATIVE AND FINANCE '),
(30, 'PMED');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `mi` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `division` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `firstname`, `lastname`, `mi`, `address`, `division`) VALUES
(13, 'vvvv', 'vvvv', 'vvv', 'vvvv', 'ADMINISTRATIVE AND FINANC'),
(14, 'jameel', 'basher', 'a', 'maura', 'PMED'),
(15, 'angel', 'encarnacon', 'a', 'aaaa', 'PMED'),
(18, 'gfdg', 'gfd', 'gfd', 'gfdg', 'ADMINISTRATIVE AND FINANC'),
(20, 'hgfh', 'gfh', 'hgf', 'ew', 'PMED'),
(21, 'xds', 'fsdf', 'fsdf', 'fsdf', 'PMED'),
(22, 'fsdf', 'vxcv', 'vcv', 'vxcv', 'PMED');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `member`
--


-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `session_id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `session_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`session_id`, `username`, `session_date`) VALUES
(1, 'aaaaaa', '2012-11-28 18:55:36'),
(2, 'bbbbbb', '2012-11-28 18:58:39'),
(3, 'aaaaaa', '2012-11-28 18:58:23'),
(4, 'jameel', '2013-01-13 20:49:32'),
(5, '123', '2012-12-07 18:36:44'),
(6, '456', '2012-12-07 18:36:14'),
(7, 'jaleel', '2013-01-13 20:47:01'),
(8, 'boniejane', '2013-01-13 20:40:43'),
(9, 'jasmin', '2013-01-13 20:48:03');

-- --------------------------------------------------------

--
-- Table structure for table `tblrequest`
--

CREATE TABLE IF NOT EXISTS `tblrequest` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `division` varchar(50) NOT NULL,
  `description` varchar(40) NOT NULL,
  `unitcost` varchar(15) NOT NULL,
  `unit` varchar(15) NOT NULL,
  `qty` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=175 ;

--
-- Dumping data for table `tblrequest`
--

INSERT INTO `tblrequest` (`id`, `name`, `date`, `division`, `description`, `unitcost`, `unit`, `qty`) VALUES
(170, '', '', 'ADMINISTRATIVE AND FINANCE ', 'bond', 'P100', 'ream', 1),
(171, '', '', 'ADMINISTRATIVE AND FINANCE ', 'bond', 'P100', 'ream', 3),
(172, '', '', 'ADMINISTRATIVE AND FINANCE ', 'aaa', 'P4', 'aaa', 2),
(173, '', '', 'ADMINISTRATIVE AND FINANCE ', 'bond', 'P100', 'ream', 5),
(174, '', '', 'ADMINISTRATIVE AND FINANCE ', 'aaa', 'P4', 'aaa', 7);

-- --------------------------------------------------------

--
-- Table structure for table `tblsupply`
--

CREATE TABLE IF NOT EXISTS `tblsupply` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `img` varchar(35) NOT NULL,
  `description` varchar(30) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `unitcost` float NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `tblsupply`
--

INSERT INTO `tblsupply` (`id`, `img`, `description`, `unit`, `quantity`, `unitcost`, `date`) VALUES
(53, 'barimage.bmp', 'bond', 'ream', 0, 100, '01/02/2013'),
(54, 'images_off.bmp', 'aaa', 'aaa', 0, 4, '01/01/2013');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE IF NOT EXISTS `tbluser` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `confirmation` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `firstname`, `lastname`, `username`, `password`, `type`, `confirmation`) VALUES
(41, 'Jameel', 'Bashers', 'Jameel', 'jameel', 'admin', '1'),
(45, 'Jaleel', 'Basher', 'jaleel', 'jaleel', '', '1'),
(46, 'bonie', 'gregorio', 'boniejane', 'boniejane', 'PMED', '1'),
(47, 'jasmin', 'jasmin', 'jasmin', 'jasmin', 'PMED', '1');
