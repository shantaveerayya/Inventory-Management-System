<link rel="stylesheet" type="text/css" href="../CSS/menu.css" />
<link rel="stylesheet" type="text/css" href="../CSS/general.css" />

<ul id="menu">
	<li><a href="../Admin/home.php">Home</a></li>
	<li>
		<a href="#">Transaction</a>
		<ul>
			<li><a href="../Admin/supply.php">STOCK</a></li>
			<li><a href="../Admin/Request/request.php">REQUEST ITEMS</a></li>
			<li><a href="../Admin/reqSupply.php">REQUESTED ITEMS</a></li>
			<li><a href="../Admin/orderPlaced.php">ORDERS PLACED</a></li>
		</ul>
	</li>
	<li>
		<a href="#">Set-up</a>
		<ul>
			<li><a href="../Admin/addDiv.php">DIVISION</a></li>
			<li><a href="../Admin/employee.php">EMPLOYEE</a></li>
			<li><a href="../Admin/userReg.php">USER MGNT</a></li>
		</ul>
	</li>
	<li>
		<a href="#">TOOLS</a>
		<ul>
			<li><a href="#">USER'S LOG</a></li>
			<li><a href="../Admin/databasebackup/backupDB.php">BACK-UP DATABASE</a></li>
		</ul>
	</li>
	<li><a href="#">Print</a></li>
	<li><a href="#">Help</a></li>
     <div style="float:right; font-family:Arial, Helvetica, sans-serif; color:#FFFFFF; margin-right:5px">
	 
     <SCRIPT LANGUAGE="Javascript">
<!-- 

// Array of day names
var dayNames = new Array("Sunday","Monday","Tuesday","Wednesday",
				"Thursday","Friday","Saturday");

// Array of month Names
var monthNames = new Array(
"January","February","March","April","May","June","July",
"August","September","October","November","December");

var now = new Date();
document.write(dayNames[now.getDay()] + ", " + 
monthNames[now.getMonth()] + " " + 
now.getDate() + ", " + now.getFullYear());

// -->
</SCRIPT>
     <div id="txt"></div>
    </div>
</ul>